"""Seeds cloudvault.db with the same demo dataset the original client-side
mock (js/db.js) used, so behavior is consistent after the swap to a real
Flask + SQLite backend. Run once (or after deleting cloudvault.db) via:
    venv/bin/python3 seed.py
"""
import os
import sqlite3
from datetime import datetime, timedelta, timezone

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "cloudvault.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def days_ago(n):
    return iso(now() - timedelta(days=n))


def days_from_now(n):
    return iso(now() + timedelta(days=n))


def seed():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(open(SCHEMA_PATH).read())
    cur = conn.cursor()

    users = [
        (1, "Riya Sharma", "riya@college.edu", "demo", "Student", 10 * 1024**3, days_ago(120)),
        (2, "Arjun Kumar", "arjun@college.edu", "demo", "Student", 10 * 1024**3, days_ago(118)),
        (3, "Dr. S. Nair", "nair@college.edu", "demo", "Faculty", 20 * 1024**3, days_ago(200)),
        (4, "Meera Pillai", "meera@college.edu", "demo", "Student", 10 * 1024**3, days_ago(90)),
        (5, "Admin Office", "admin@college.edu", "demo", "Admin", 50 * 1024**3, days_ago(300)),
    ]
    cur.executemany(
        "INSERT INTO users (user_id,name,email,password,role,storage_quota_bytes,created_at) VALUES (?,?,?,?,?,?,?)",
        users,
    )

    groups = [
        (1, "CloudVault Project Team", "D15 project group", 1, days_ago(80)),
        (2, "DBMS — Faculty", "Faculty reviewers", 3, days_ago(70)),
        (3, "Sem 7 Batch", "Whole batch broadcast group", 5, days_ago(200)),
    ]
    cur.executemany(
        "INSERT INTO user_groups (group_id,group_name,description,created_by,created_at) VALUES (?,?,?,?,?)",
        groups,
    )

    group_members = [
        (1, 1, days_ago(80)), (1, 2, days_ago(79)), (1, 4, days_ago(75)),
        (2, 3, days_ago(70)),
        (3, 1, days_ago(200)), (3, 2, days_ago(200)), (3, 4, days_ago(200)),
    ]
    cur.executemany("INSERT INTO group_members (group_id,user_id,joined_at) VALUES (?,?,?)", group_members)

    folders = [
        (1, "Project Report", None, 1, days_ago(60)),
        (2, "Diagrams", 1, 1, days_ago(55)),
    ]
    cur.executemany(
        "INSERT INTO folders (folder_id,folder_name,parent_folder_id,owner_id,created_at) VALUES (?,?,?,?,?)",
        folders,
    )

    files = [
        (1, "CloudVault_Final_Report.pdf", 1, 1, 0, None, days_ago(20)),
        (2, "ER_Diagram_v2.png", 2, 2, 0, None, days_ago(10)),
        (3, "schema_dump.sql", None, 1, 0, None, days_ago(9)),
        (4, "sample_dataset.xlsx", None, 1, 0, None, days_ago(9)),
        (5, "source_code_backup.zip", None, 1, 0, None, days_ago(7)),
        (6, "old_draft_notes.docx", None, 1, 1, days_ago(2), days_ago(30)),
    ]
    cur.executemany(
        "INSERT INTO files (file_id,file_name,folder_id,owner_id,is_deleted,deleted_at,created_at) VALUES (?,?,?,?,?,?,?)",
        files,
    )

    e410 = "e410f1a2b8c4d9e0a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6071"
    versions = [
        (1, 1, 1, 2202009, e410, "seed/e410f1", 1, days_ago(20)),
        (2, 1, 2, 2202009, e410, "seed/e410f1", 1, days_ago(9)),
        (3, 1, 3, 2412459, "9b21aa334455bb66cc77dd88ee99ff0011223344556677889900aabbccdd70", "seed/9b21aa", 2, days_ago(2)),
        (4, 1, 4, 2517412, "4a7fbb112233445566778899aabbccddeeff00112233445566778899aae91c", "seed/4a7fbb", 1, iso(now())),
        (5, 2, 1, 780000, "7c3a112233445566778899aabbccddeeff0011223344556677889900aa90de", "seed/7c3a11", 2, days_ago(12)),
        (6, 2, 2, 860000, "2f5cbb445566778899aabbccddeeff0011223344556677889900aabbcc1122", "seed/2f5cbb", 2, days_ago(10)),
        (7, 3, 1, 45056, e410, "seed/e410f1", 1, days_ago(9)),
        (8, 4, 1, 1153434, "aa11bb22cc33dd44ee55ff6600112233445566778899aabbccddeeff001122", "seed/aa11bb", 1, days_ago(9)),
        (9, 5, 1, 4200000, "d1d2d3d4d5d6d7d8d9dadbdcdddedfe0e1e2e3e4e5e6e7e8e9eaebecedeeef0", "seed/d1d2d3", 1, days_ago(20)),
        (10, 5, 2, 9800000, "c1c2c3c4c5c6c7c8c9cacbcccdcecfd0d1d2d3d4d5d6d7d8d9dadbdcdddedf1", "seed/c1c2c3", 1, days_ago(12)),
        (11, 5, 3, 19608272, "b1b2b3b4b5b6b7b8b9babbbcbdbebfc0c1c2c3c4c5c6c7c8c9cacbcccdcecf2", "seed/b1b2b3", 1, days_ago(7)),
        (12, 6, 1, 30210, "aaaa1111bbbb2222cccc3333dddd4444eeee5555ffff6666000011112222aa", "seed/aaaa11", 1, days_ago(30)),
    ]
    cur.executemany(
        "INSERT INTO file_versions (version_id,file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?,?)",
        versions,
    )

    tags = [(1, "report"), (2, "diagram"), (3, "db"), (4, "sql"), (5, "data"), (6, "backup")]
    cur.executemany("INSERT INTO tags (tag_id,tag_name) VALUES (?,?)", tags)

    file_tags = [(1, 1), (2, 2), (3, 3), (3, 4), (4, 5), (5, 6)]
    cur.executemany("INSERT INTO file_tags (file_id,tag_id) VALUES (?,?)", file_tags)

    file_user_perms = [
        (1, 1, "Owner", 1, days_ago(20)),
        (1, 2, "Editor", 1, days_ago(15)),
        (1, 4, "Viewer", 1, days_ago(14)),
        (3, 1, "Owner", 1, days_ago(9)),
        (3, 2, "Editor", 1, days_ago(9)),
    ]
    cur.executemany(
        "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
        file_user_perms,
    )

    file_group_perms = [(1, 3, "Viewer", 1, days_ago(4))]
    cur.executemany(
        "INSERT INTO file_group_permissions (file_id,group_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
        file_group_perms,
    )

    share_links = [(1, 1, "8f3k-report", 1, days_from_now(150), 10, 3, days_ago(4))]
    cur.executemany(
        "INSERT INTO share_links (link_id,file_id,token,created_by,expiry_date,max_downloads,download_count,created_at) VALUES (?,?,?,?,?,?,?,?)",
        share_links,
    )

    activity = [
        (1, 1, 1, "Upload", days_ago(20), "uploaded version 1"),
        (2, 2, 2, "Upload", days_ago(12), "uploaded version 1"),
        (3, 1, 1, "Upload", days_ago(9), "uploaded version 2"),
        (4, 3, 1, "Upload", days_ago(9), "uploaded version 1 (duplicate of schema_dump content)"),
        (5, 4, 1, "Upload", days_ago(9), "uploaded version 1"),
        (6, 2, 2, "Upload", days_ago(10), "uploaded version 2"),
        (7, 5, 1, "Upload", days_ago(7), "uploaded version 3"),
        (8, 6, 2, "Delete", days_ago(2), "deleted a draft copy"),
        (9, 1, 2, "Modify", days_ago(2), "uploaded version 3"),
        (10, 1, 1, "Share", days_ago(4), "shared with Sem 7 Batch"),
        (11, 1, 1, "Upload", iso(now()), "uploaded version 4"),
        (12, 3, 5, "Share", days_ago(1), "created a share link (expires in 150 days)"),
    ]
    cur.executemany(
        "INSERT INTO activity_logs (log_id,file_id,user_id,action_type,action_time,details) VALUES (?,?,?,?,?,?)",
        activity,
    )

    # Keep autoincrement counters ahead of the highest seeded id.
    for table, col in [
        ("users", "user_id"), ("user_groups", "group_id"), ("folders", "folder_id"),
        ("files", "file_id"), ("file_versions", "version_id"), ("tags", "tag_id"),
        ("share_links", "link_id"), ("activity_logs", "log_id"),
    ]:
        cur.execute(f"SELECT MAX({col}) FROM {table}")
        max_id = cur.fetchone()[0] or 0
        updated = cur.execute("UPDATE sqlite_sequence SET seq=? WHERE name=?", (max_id, table)).rowcount
        if not updated:
            cur.execute("INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)", (table, max_id))

    conn.commit()
    conn.close()
    print(f"Seeded {DB_PATH}")


if __name__ == "__main__":
    seed()
