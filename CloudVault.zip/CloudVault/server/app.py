import hashlib
import os
import secrets
import sqlite3
from datetime import datetime, timezone

from flask import Flask, g, jsonify, request, session, send_from_directory, abort

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "cloudvault.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
APP_DIR = os.path.join(os.path.dirname(BASE_DIR), "app")

app = Flask(__name__, static_folder=None)
app.secret_key = os.environ.get("CLOUDVAULT_SECRET", "dev-secret-change-me")


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    return dict(r) if r else None


def public_user(user):
    u = dict(user)
    u.pop("password", None)
    return u


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return one(get_db().execute("SELECT * FROM users WHERE user_id=?", (uid,)))


def require_user():
    user = current_user()
    if not user:
        abort(401, description="Not signed in")
    return user


def require_admin():
    user = require_user()
    if user["role"] != "Admin":
        abort(403, description="Admin only")
    return user


def log_activity(db, file_id, user_id, action_type, details):
    db.execute(
        "INSERT INTO activity_logs (file_id,user_id,action_type,action_time,details) VALUES (?,?,?,?,?)",
        (file_id, user_id, action_type, now_iso(), details),
    )


@app.errorhandler(400)
@app.errorhandler(401)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(409)
def handle_error(e):
    return jsonify({"error": getattr(e, "description", str(e))}), e.code


# ---------------- static frontend ----------------
@app.route("/")
def index():
    return send_from_directory(APP_DIR, "login.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(APP_DIR, filename)


# ---------------- auth ----------------
@app.get("/api/demo-accounts")
def demo_accounts():
    db = get_db()
    return jsonify(rows(db.execute("SELECT name, email, role FROM users ORDER BY user_id")))


@app.post("/api/auth/login")
def login():
    body = request.get_json(force=True)
    db = get_db()
    user = one(db.execute("SELECT * FROM users WHERE email=?", (body.get("email", "").strip(),)))
    if not user or user["password"] != body.get("password"):
        abort(401, description="Incorrect email or password.")
    session["user_id"] = user["user_id"]
    return jsonify(public_user(user))


@app.post("/api/auth/register")
def register():
    body = request.get_json(force=True)
    db = get_db()
    name, email, password, role = body.get("name", "").strip(), body.get("email", "").strip(), body.get("password"), body.get("role", "Student")
    if not name or not email or not password:
        abort(400, description="Name, email and password are required.")
    if one(db.execute("SELECT 1 FROM users WHERE email=?", (email,))):
        abort(409, description="An account with that email already exists.")
    cur = db.execute(
        "INSERT INTO users (name,email,password,role,storage_quota_bytes,created_at) VALUES (?,?,?,?,?,?)",
        (name, email, password, role, 10 * 1024**3, now_iso()),
    )
    db.commit()
    session["user_id"] = cur.lastrowid
    return jsonify(public_user(one(db.execute("SELECT * FROM users WHERE user_id=?", (cur.lastrowid,)))))


@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/session")
def get_session():
    user = current_user()
    if not user:
        abort(401)
    return jsonify(public_user(user))


# ---------------- snapshot ----------------
@app.get("/api/snapshot")
def snapshot():
    require_user()
    db = get_db()
    tables = [
        "users", "user_groups", "group_members", "folders", "files", "file_versions",
        "tags", "file_tags", "file_user_permissions", "file_group_permissions",
        "share_links", "activity_logs",
    ]
    data = {t: rows(db.execute(f"SELECT * FROM {t}")) for t in tables}
    for u in data["users"]:
        u.pop("password", None)
    return jsonify(data)


# ---------------- users (admin) ----------------
@app.patch("/api/users/<int:user_id>")
def update_user(user_id):
    require_admin()
    body = request.get_json(force=True)
    db = get_db()
    if "role" in body:
        db.execute("UPDATE users SET role=? WHERE user_id=?", (body["role"], user_id))
    if "storage_quota_bytes" in body:
        db.execute("UPDATE users SET storage_quota_bytes=? WHERE user_id=?", (body["storage_quota_bytes"], user_id))
    db.commit()
    return jsonify({"ok": True})


# ---------------- groups ----------------
@app.post("/api/groups")
def create_group():
    user = require_user()
    body = request.get_json(force=True)
    name = body.get("group_name", "").strip()
    if not name:
        abort(400, description="Group name is required.")
    db = get_db()
    if one(db.execute("SELECT 1 FROM user_groups WHERE group_name=?", (name,))):
        abort(409, description="A group with that name already exists.")
    cur = db.execute(
        "INSERT INTO user_groups (group_name,description,created_by,created_at) VALUES (?,?,?,?)",
        (name, body.get("description", ""), user["user_id"], now_iso()),
    )
    db.execute(
        "INSERT INTO group_members (group_id,user_id,joined_at) VALUES (?,?,?)",
        (cur.lastrowid, user["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"group_id": cur.lastrowid})


@app.post("/api/groups/<int:group_id>/members")
def add_member(group_id):
    require_user()
    body = request.get_json(force=True)
    db = get_db()
    db.execute(
        "INSERT OR IGNORE INTO group_members (group_id,user_id,joined_at) VALUES (?,?,?)",
        (group_id, body["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/groups/<int:group_id>/members/<int:user_id>")
def remove_member(group_id, user_id):
    require_user()
    db = get_db()
    db.execute("DELETE FROM group_members WHERE group_id=? AND user_id=?", (group_id, user_id))
    db.commit()
    return jsonify({"ok": True})


# ---------------- folders ----------------
@app.post("/api/folders")
def create_folder():
    user = require_user()
    body = request.get_json(force=True)
    name = body.get("folder_name", "").strip()
    parent_id = body.get("parent_folder_id")
    if not name:
        abort(400, description="Folder name is required.")
    db = get_db()
    exists = one(db.execute(
        "SELECT 1 FROM folders WHERE owner_id=? AND parent_folder_id IS ? AND folder_name=?",
        (user["user_id"], parent_id, name),
    ))
    if exists:
        abort(409, description="A folder with that name already exists here.")
    cur = db.execute(
        "INSERT INTO folders (folder_name,parent_folder_id,owner_id,created_at) VALUES (?,?,?,?)",
        (name, parent_id, user["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"folder_id": cur.lastrowid})


# ---------------- files & versions ----------------
def hash_and_store(file_storage):
    data = file_storage.read()
    checksum = hashlib.sha256(data).hexdigest()
    path = os.path.join(UPLOAD_DIR, checksum)
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(data)
    return checksum, len(data), f"uploads/{checksum}"


@app.post("/api/files")
def upload_file():
    user = require_user()
    if "file" not in request.files:
        abort(400, description="No file provided.")
    upload = request.files["file"]
    folder_id = request.form.get("folder_id")
    folder_id = int(folder_id) if folder_id else None
    db = get_db()

    existing = one(db.execute(
        "SELECT * FROM files WHERE owner_id=? AND folder_id IS ? AND file_name=? AND is_deleted=0",
        (user["user_id"], folder_id, upload.filename),
    ))
    checksum, size, storage_path = hash_and_store(upload)

    if existing:
        file_id = existing["file_id"]
    else:
        cur = db.execute(
            "INSERT INTO files (file_name,folder_id,owner_id,is_deleted,created_at) VALUES (?,?,?,0,?)",
            (upload.filename, folder_id, user["user_id"], now_iso()),
        )
        file_id = cur.lastrowid
        db.execute(
            "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
            (file_id, user["user_id"], "Owner", user["user_id"], now_iso()),
        )

    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    dup = one(db.execute("SELECT 1 FROM file_versions WHERE checksum=? AND file_id!=?", (checksum, file_id)))
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, size, checksum, storage_path, user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Upload" if version_no == 1 else "Modify",
                 f"uploaded version {version_no}" + (" (duplicate content — storage reused)" if dup else ""))
    db.commit()
    return jsonify({"file_id": file_id, "version_no": version_no, "checksum": checksum, "duplicate": bool(dup)})


@app.post("/api/files/<int:file_id>/versions")
def upload_version(file_id):
    user = require_user()
    if "file" not in request.files:
        abort(400, description="No file provided.")
    upload = request.files["file"]
    db = get_db()
    checksum, size, storage_path = hash_and_store(upload)
    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    dup = one(db.execute("SELECT 1 FROM file_versions WHERE checksum=? AND file_id!=?", (checksum, file_id)))
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, size, checksum, storage_path, user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Upload" if version_no == 1 else "Modify",
                 f"uploaded version {version_no}" + (" (duplicate content — storage reused)" if dup else ""))
    db.commit()
    return jsonify({"version_no": version_no, "checksum": checksum, "duplicate": bool(dup)})


@app.post("/api/files/<int:file_id>/versions/<int:version_id>/restore")
def restore_version(file_id, version_id):
    user = require_user()
    db = get_db()
    target = one(db.execute("SELECT * FROM file_versions WHERE version_id=? AND file_id=?", (version_id, file_id)))
    if not target:
        abort(404)
    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, target["size_bytes"], target["checksum"], target["storage_path"], user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Restore", f"restored version {target['version_no']} as new version {version_no}")
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/files/<int:file_id>/download")
def download_file(file_id):
    user = require_user()
    db = get_db()
    version = one(db.execute(
        "SELECT * FROM file_versions WHERE file_id=? ORDER BY version_no DESC LIMIT 1", (file_id,)
    ))
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not version or not f:
        abort(404)
    log_activity(db, file_id, user["user_id"], "Download", "downloaded current version")
    db.commit()
    full_path = os.path.join(BASE_DIR, version["storage_path"])
    if not os.path.exists(full_path):
        abort(404, description="Demo file — no binary content stored for this seeded version.")
    return send_from_directory(UPLOAD_DIR, version["checksum"], as_attachment=True, download_name=f["file_name"])


@app.patch("/api/files/<int:file_id>")
def update_file(file_id):
    user = require_user()
    body = request.get_json(force=True)
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    if "file_name" in body:
        db.execute("UPDATE files SET file_name=? WHERE file_id=?", (body["file_name"], file_id))
        log_activity(db, file_id, user["user_id"], "Modify", f"renamed \"{f['file_name']}\" to \"{body['file_name']}\"")
    if "folder_id" in body:
        folder_id = body["folder_id"]
        db.execute("UPDATE files SET folder_id=? WHERE file_id=?", (folder_id, file_id))
        dest = "My Files (root)"
        if folder_id:
            folder = one(db.execute("SELECT folder_name FROM folders WHERE folder_id=?", (folder_id,)))
            dest = folder["folder_name"] if folder else dest
        log_activity(db, file_id, user["user_id"], "Modify", f"moved to {dest}")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/copy")
def copy_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    version = one(db.execute("SELECT * FROM file_versions WHERE file_id=? ORDER BY version_no DESC LIMIT 1", (file_id,)))
    base, dot, ext = f["file_name"].partition(".")
    new_name = f"{base} (copy){dot}{ext}"
    cur = db.execute(
        "INSERT INTO files (file_name,folder_id,owner_id,is_deleted,created_at) VALUES (?,?,?,0,?)",
        (new_name, f["folder_id"], user["user_id"], now_iso()),
    )
    new_id = cur.lastrowid
    db.execute(
        "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
        (new_id, user["user_id"], "Owner", user["user_id"], now_iso()),
    )
    if version:
        db.execute(
            "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,1,?,?,?,?,?)",
            (new_id, version["size_bytes"], version["checksum"], version["storage_path"], user["user_id"], now_iso()),
        )
    for t in rows(db.execute("SELECT tag_id FROM file_tags WHERE file_id=?", (file_id,))):
        db.execute("INSERT INTO file_tags (file_id,tag_id) VALUES (?,?)", (new_id, t["tag_id"]))
    log_activity(db, new_id, user["user_id"], "Upload", f"copied from \"{f['file_name']}\"")
    db.commit()
    return jsonify({"file_id": new_id})


@app.delete("/api/files/<int:file_id>")
def soft_delete_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    db.execute("UPDATE files SET is_deleted=1, deleted_at=? WHERE file_id=?", (now_iso(), file_id))
    log_activity(db, file_id, user["user_id"], "Delete", f"moved \"{f['file_name']}\" to trash")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/restore")
def restore_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    db.execute("UPDATE files SET is_deleted=0, deleted_at=NULL WHERE file_id=?", (file_id,))
    log_activity(db, file_id, user["user_id"], "Restore", f"restored \"{f['file_name']}\" from trash")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permanent")
def permanent_delete_file(file_id):
    require_user()
    db = get_db()
    for table in ["file_versions", "file_tags", "file_user_permissions", "file_group_permissions", "share_links", "activity_logs"]:
        db.execute(f"DELETE FROM {table} WHERE file_id=?", (file_id,))
    db.execute("DELETE FROM files WHERE file_id=?", (file_id,))
    db.commit()
    return jsonify({"ok": True})


# ---------------- tags ----------------
@app.post("/api/files/<int:file_id>/tags")
def add_tag(file_id):
    require_user()
    body = request.get_json(force=True)
    name = body.get("tag_name", "").strip().lower()
    if not name:
        abort(400, description="Tag name is required.")
    db = get_db()
    tag = one(db.execute("SELECT * FROM tags WHERE tag_name=?", (name,)))
    if not tag:
        cur = db.execute("INSERT INTO tags (tag_name) VALUES (?)", (name,))
        tag_id = cur.lastrowid
    else:
        tag_id = tag["tag_id"]
    db.execute("INSERT OR IGNORE INTO file_tags (file_id,tag_id) VALUES (?,?)", (file_id, tag_id))
    db.commit()
    return jsonify({"tag_id": tag_id})


@app.delete("/api/files/<int:file_id>/tags/<int:tag_id>")
def remove_tag(file_id, tag_id):
    require_user()
    db = get_db()
    db.execute("DELETE FROM file_tags WHERE file_id=? AND tag_id=?", (file_id, tag_id))
    db.commit()
    return jsonify({"ok": True})


# ---------------- permissions ----------------
@app.post("/api/files/<int:file_id>/permissions/user")
def grant_user_permission(file_id):
    user = require_user()
    body = request.get_json(force=True)
    db = get_db()
    db.execute(
        "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?) "
        "ON CONFLICT(file_id,user_id) DO UPDATE SET permission_type=excluded.permission_type",
        (file_id, body["user_id"], body["permission_type"], user["user_id"], now_iso()),
    )
    target = one(db.execute("SELECT name FROM users WHERE user_id=?", (body["user_id"],)))
    log_activity(db, file_id, user["user_id"], "Share", f"granted {body['permission_type']} to {target['name']}")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permissions/user/<int:user_id>")
def revoke_user_permission(file_id, user_id):
    actor = require_user()
    db = get_db()
    db.execute("DELETE FROM file_user_permissions WHERE file_id=? AND user_id=?", (file_id, user_id))
    target = one(db.execute("SELECT name FROM users WHERE user_id=?", (user_id,)))
    log_activity(db, file_id, actor["user_id"], "Modify", f"removed access for {target['name'] if target else 'user'}")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/permissions/group")
def grant_group_permission(file_id):
    user = require_user()
    body = request.get_json(force=True)
    db = get_db()
    db.execute(
        "INSERT INTO file_group_permissions (file_id,group_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?) "
        "ON CONFLICT(file_id,group_id) DO UPDATE SET permission_type=excluded.permission_type",
        (file_id, body["group_id"], body["permission_type"], user["user_id"], now_iso()),
    )
    target = one(db.execute("SELECT group_name FROM user_groups WHERE group_id=?", (body["group_id"],)))
    log_activity(db, file_id, user["user_id"], "Share", f"shared with group {target['group_name']} ({body['permission_type']})")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permissions/group/<int:group_id>")
def revoke_group_permission(file_id, group_id):
    actor = require_user()
    db = get_db()
    db.execute("DELETE FROM file_group_permissions WHERE file_id=? AND group_id=?", (file_id, group_id))
    target = one(db.execute("SELECT group_name FROM user_groups WHERE group_id=?", (group_id,)))
    log_activity(db, file_id, actor["user_id"], "Modify", f"removed group access for {target['group_name'] if target else 'group'}")
    db.commit()
    return jsonify({"ok": True})


# ---------------- share links ----------------
@app.post("/api/files/<int:file_id>/share-links")
def create_share_link(file_id):
    user = require_user()
    body = request.get_json(force=True) or {}
    db = get_db()
    token = secrets.token_hex(4)[:4] + "-" + secrets.token_hex(4)
    db.execute(
        "INSERT INTO share_links (file_id,token,created_by,expiry_date,max_downloads,download_count,created_at) VALUES (?,?,?,?,?,0,?)",
        (file_id, token, user["user_id"], body.get("expiry_date"), body.get("max_downloads"), now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Share", "created a public share link")
    db.commit()
    return jsonify({"token": token})


@app.delete("/api/share-links/<int:link_id>")
def revoke_share_link(link_id):
    user = require_user()
    db = get_db()
    link = one(db.execute("SELECT * FROM share_links WHERE link_id=?", (link_id,)))
    db.execute("DELETE FROM share_links WHERE link_id=?", (link_id,))
    if link:
        log_activity(db, link["file_id"], user["user_id"], "Modify", "revoked a share link")
    db.commit()
    return jsonify({"ok": True})


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        import seed
        seed.seed()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    app.run(host="127.0.0.1", port=5050, debug=True)
