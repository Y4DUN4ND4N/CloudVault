(async () => {
  const user = await CV.requireSession();
  if (!user) return;
  CV.initTopnav();

  const S = {
    view: "mine", folderId: null, groupId: null, search: "",
    sortKey: "name", sortDir: "asc", selectedFileId: null, checked: new Set(),
  };

  const ACTION_DOT = { Upload: "dot-upload", Share: "dot-share", Modify: "dot-mod", Delete: "dot-del", Restore: "dot-restore", Download: "dot-share" };

  // ---------------- data access for current view ----------------
  function currentFiles() {
    if (S.search) {
      if (S.view === "mine" && !S.groupId) {
        const q = S.search.toLowerCase();
        return DB.allOwnedFiles(user.user_id).filter((f) => {
          const tags = DB.fileTags(f.file_id).map((t) => t.tag_name).join(" ");
          return f.file_name.toLowerCase().includes(q) || tags.includes(q);
        });
      }
      return DB.searchFiles(user.user_id, S.search, S.view, S.folderId, S.groupId);
    }
    return DB.visibleFiles(user.user_id, S.view, S.folderId, S.groupId);
  }

  function currentFolders() {
    if (S.view !== "mine" || S.search) return [];
    return DB.listFolders(user.user_id, S.folderId);
  }

  // ---------------- sidebar ----------------
  function renderSidebar() {
    CV.qs("#cnt-mine").textContent = DB.countFiles(user.user_id, "mine");
    CV.qs("#cnt-shared-with-me").textContent = DB.countFiles(user.user_id, "shared-with-me");
    CV.qs("#cnt-shared-by-me").textContent = DB.countFiles(user.user_id, "shared-by-me");
    CV.qs("#cnt-tagged").textContent = DB.countFiles(user.user_id, "tagged");
    CV.qs("#cnt-trash").textContent = DB.countFiles(user.user_id, "trash");

    CV.qsa(".sidebar .nav-item[data-view]").forEach((el) => {
      el.classList.toggle("active", el.dataset.view === S.view && !S.groupId);
    });

    const groupList = CV.qs("#groupNavList");
    const groups = DB.listUserGroups(user.user_id);
    groupList.innerHTML = groups.map((g) => `
      <div class="nav-item${S.groupId === g.group_id ? " active" : ""}" data-group="${g.group_id}">
        <span>${ICON("users", 15)}${CV.escapeHtml(g.group_name)}</span>
        <span class="count">${DB.listGroupMembers(g.group_id).length}</span>
      </div>`).join("") || `<div class="nav-empty">No groups yet</div>`;
    CV.qsa("#groupNavList .nav-item").forEach((el) => {
      el.addEventListener("click", () => {
        S.view = "group"; S.groupId = Number(el.dataset.group); S.folderId = null; S.search = "";
        CV.qs("#searchInput").value = "";
        S.selectedFileId = null;
        renderAll();
      });
    });

    const used = DB.userStorageUsed(user.user_id);
    const quota = user.storage_quota_bytes;
    const pct = Math.min(100, (used / quota) * 100);
    CV.qs("#storageText").innerHTML = `<b>${CV.formatBytes(used)}</b> of ${CV.formatBytes(quota)} used`;
    const fill = CV.qs("#storageFill");
    fill.style.width = pct.toFixed(1) + "%";
    fill.classList.toggle("warn", pct > 85);
    CV.qs("#dedupText").textContent = `Checksum dedup saved ${CV.formatBytes(DB.dedupSavingsBytes())}`;
  }

  // ---------------- breadcrumb ----------------
  function renderCrumb() {
    const crumb = CV.qs("#crumb");
    const labels = { mine: "My Files", "shared-with-me": "Shared with me", "shared-by-me": "Shared by me", tagged: "Tagged", trash: "Deleted" };
    if (S.groupId) {
      const g = DB.getGroup(S.groupId);
      crumb.innerHTML = `<span class="crumb-current">${CV.escapeHtml(g ? g.group_name : "Group")}</span>`;
      return;
    }
    let html = `<span class="crumb-link" data-root>${labels[S.view] || "My Files"}</span>`;
    if (S.view === "mine" && S.folderId) {
      DB.folderPath(S.folderId).forEach((f) => {
        html += `<span class="sep">/</span><span class="crumb-link" data-folder="${f.folder_id}">${CV.escapeHtml(f.folder_name)}</span>`;
      });
    }
    // last segment isn't a link
    const parts = html.split(`<span class="sep">/</span>`);
    parts[parts.length - 1] = parts[parts.length - 1].replace("crumb-link", "crumb-current");
    crumb.innerHTML = parts.join(`<span class="sep">/</span>`);
    CV.qs("#crumb [data-root]")?.addEventListener("click", () => { S.folderId = null; renderAll(); });
    CV.qsa("#crumb [data-folder]").forEach((el) => {
      el.addEventListener("click", () => { S.folderId = Number(el.dataset.folder); renderAll(); });
    });
  }

  // ---------------- table ----------------
  function sharedWithSummary(fileId) {
    const perms = DB.filePermissions(fileId).filter((p) => !(p.kind === "user" && p.subject && p.subject.user_id === user.user_id));
    if (!perms.length) return `<span class="meta-muted">Private</span>`;
    const avatars = perms.slice(0, 3).map((p) => `<div class="avatar" title="${CV.escapeHtml(p.subject ? (p.subject.name || p.subject.group_name) : "")}">${CV.escapeHtml(CV.initials(p.subject ? (p.subject.name || p.subject.group_name) : "?"))}</div>`).join("");
    const extra = perms.length > 3 ? `<div class="avatar">+${perms.length - 3}</div>` : "";
    return `<div class="avatars">${avatars}${extra}</div>`;
  }

  function renderFolderRow(folder) {
    return `<tr data-folder-row="${folder.folder_id}">
      <td class="chk-col"></td>
      <td><div class="file-name">
        <div class="file-glyph glyph-folder">${ICON("folder", 16)}</div>
        <div class="fname-text"><div class="name-line">${CV.escapeHtml(folder.folder_name)}</div><div class="sub">Folder</div></div>
      </div></td>
      <td class="meta-muted">${CV.escapeHtml(DB.getUser(folder.owner_id).name)}</td>
      <td class="meta-muted">${CV.timeAgo(folder.created_at)}</td>
      <td class="meta-muted">—</td><td class="meta-muted">—</td><td class="meta-muted">—</td>
      <td></td>
    </tr>`;
  }

  function renderFileRow(f) {
    const v = DB.currentVersion(f.file_id);
    const glyph = CV.fileGlyph(f.file_name);
    const owner = DB.getUser(f.owner_id);
    const tags = DB.fileTags(f.file_id).map((t) => t.tag_name).join(", ") || "—";
    const versions = DB.fileVersions(f.file_id);
    const isDupContent = v && DB.findVersionByChecksum(v.checksum) !== v;
    const checked = S.checked.has(f.file_id);
    return `<tr data-file-row="${f.file_id}" class="${S.selectedFileId === f.file_id ? "selected" : ""}${checked ? " row-checked" : ""}">
      <td class="chk-col"><span class="chk${checked ? " checked" : ""}" data-chk="${f.file_id}" role="checkbox" aria-checked="${checked}" tabindex="0">${checked ? ICON("check", 11) : ""}</span></td>
      <td><div class="file-name">
        <div class="file-glyph ${glyph.cls}">${glyph.label}</div>
        <div class="fname-text">
          <div class="name-line">${CV.escapeHtml(f.file_name)}${isDupContent ? `<span class="badge badge-dup">dup</span>` : ""}</div>
          <div class="sub">Version ${v ? v.version_no : 1} of ${versions.length}${S.view === "trash" ? " · deleted " + CV.timeAgo(f.deleted_at) : ""}</div>
        </div>
      </div></td>
      <td class="meta-muted">${owner.user_id === user.user_id ? "you" : CV.escapeHtml(owner.name)}</td>
      <td class="meta-muted">${v ? CV.timeAgo(v.uploaded_at) : CV.timeAgo(f.created_at)}</td>
      <td class="meta-muted">${v ? CV.formatBytes(v.size_bytes) : "—"}</td>
      <td>${S.view === "trash" ? '<span class="meta-muted">—</span>' : sharedWithSummary(f.file_id)}</td>
      <td class="meta-muted">${CV.escapeHtml(tags)}</td>
      <td>
        <div class="menu-wrap row-actions">
          <button class="icon-btn" data-rowmenu="${f.file_id}" style="width:26px;height:26px;">⋯</button>
          <div class="menu" id="rowmenu-${f.file_id}"></div>
        </div>
      </td>
    </tr>`;
  }

  function rowMenuHtml(f) {
    if (S.view === "trash") {
      return `<div class="menu-item" data-act="restore">${ICON("restore", 14)}Restore</div>
        <div class="menu-item danger" data-act="perm-delete">${ICON("trash", 14)}Delete permanently</div>`;
    }
    return `<div class="menu-item" data-act="download">${ICON("download", 14)}Download</div>
      <div class="menu-item" data-act="rename">${ICON("pencil", 14)}Rename</div>
      <div class="menu-item" data-act="move">${ICON("arrowRight", 14)}Move to…</div>
      <div class="menu-item" data-act="copy">${ICON("copy", 14)}Make a copy</div>
      <div class="menu-sep"></div>
      <div class="menu-item danger" data-act="delete">${ICON("trash", 14)}Delete</div>`;
  }

  function renderTable() {
    const files = DB.sortFiles(currentFiles(), S.sortKey, S.sortDir);
    const foldersSorted = currentFolders().sort((a, b) => a.folder_name.localeCompare(b.folder_name) * (S.sortDir === "asc" ? 1 : -1));

    const finalRows = S.sortKey === "name"
      ? foldersSorted.map(renderFolderRow).join("") + files.map(renderFileRow).join("")
      : files.map(renderFileRow).join("");

    CV.qs("#fileRows").innerHTML = finalRows;
    const empty = finalRows.length === 0;
    CV.qs("#emptyState").style.display = empty ? "block" : "none";
    CV.qs("#emptyStateSub").textContent = S.view === "trash" ? "Deleted files show up here for recovery." : S.search ? "No files match your search." : "Upload a file or adjust your filters.";

    CV.qsa("thead th[data-sort]").forEach((th) => th.classList.toggle("sorted", th.dataset.sort === S.sortKey));

    // wire rows
    CV.qsa("#fileRows tr[data-folder-row]").forEach((tr) => {
      tr.addEventListener("click", () => { S.folderId = Number(tr.dataset.folderRow); S.selectedFileId = null; renderAll(); });
    });
    CV.qsa("#fileRows tr[data-file-row]").forEach((tr) => {
      const fid = Number(tr.dataset.fileRow);
      tr.addEventListener("click", (e) => {
        if (e.target.closest("[data-chk]") || e.target.closest(".menu-wrap")) return;
        S.selectedFileId = fid;
        renderAll();
      });
    });
    CV.qsa("[data-chk]").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        const fid = Number(el.dataset.chk);
        if (S.checked.has(fid)) S.checked.delete(fid); else S.checked.add(fid);
        renderAll();
      });
    });
    CV.qsa("[data-rowmenu]").forEach((btn) => {
      const fid = Number(btn.dataset.rowmenu);
      const menu = CV.qs("#rowmenu-" + fid);
      menu.innerHTML = rowMenuHtml(DB.getFile(fid));
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        const wasOpen = menu.classList.contains("show");
        CV.qsa(".menu.show").forEach((m) => m.classList.remove("show"));
        if (!wasOpen) menu.classList.add("show");
      });
      CV.qsa(".menu-item", menu).forEach((item) => {
        item.addEventListener("click", (e) => {
          e.stopPropagation();
          menu.classList.remove("show");
          handleRowAction(fid, item.dataset.act);
        });
      });
    });

    updateSelectAllChk();
    updateBulkToolbar();
  }

  function updateSelectAllChk() {
    const files = currentFiles();
    const allChecked = files.length > 0 && files.every((f) => S.checked.has(f.file_id));
    const el = CV.qs("#selectAllChk");
    el.classList.toggle("checked", allChecked);
    el.innerHTML = allChecked ? ICON("check", 11) : "";
    el.setAttribute("aria-checked", String(allChecked));
  }

  function updateBulkToolbar() {
    const bar = CV.qs("#bulkToolbar");
    bar.classList.toggle("show", S.checked.size > 0);
    CV.qs("#bulkCount").textContent = S.checked.size;
  }

  document.addEventListener("click", () => CV.qsa(".menu.show").forEach((m) => m.classList.remove("show")));
  CV.qs("#detailBackdrop").addEventListener("click", () => { S.selectedFileId = null; renderAll(); });

  // Narrow viewports: the sidebar is off-canvas, so it needs a way in and out.
  const sidebarEl = CV.qs(".sidebar");
  const navToggle = CV.qs("#navToggle");
  const navBackdrop = CV.qs("#navBackdrop");
  function setNav(open) {
    sidebarEl.classList.toggle("open", open);
    navBackdrop.classList.toggle("show", open);
    navToggle.setAttribute("aria-expanded", String(open));
  }
  navToggle.addEventListener("click", (e) => { e.stopPropagation(); setNav(!sidebarEl.classList.contains("open")); });
  navBackdrop.addEventListener("click", () => setNav(false));
  sidebarEl.addEventListener("click", (e) => { if (e.target.closest(".nav-item")) setNav(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") setNav(false); });

  // ---------------- row / bulk actions ----------------
  async function handleRowAction(fileId, action) {
    const f = DB.getFile(fileId);
    if (action === "download") return doDownload(fileId);
    if (action === "rename") return openRenameModal(fileId);
    if (action === "move") return openMoveModal([fileId]);
    if (action === "copy") { await DB.copyFile(fileId); CV.toast(`Copied "${f.file_name}".`, "ok"); return renderAll(); }
    if (action === "delete") {
      await DB.softDeleteFile(fileId);
      CV.toast(`Moved "${f.file_name}" to trash.`);
      if (S.selectedFileId === fileId) S.selectedFileId = null;
      return renderAll();
    }
    if (action === "restore") { await DB.restoreFile(fileId); CV.toast(`Restored "${f.file_name}".`, "ok"); return renderAll(); }
    if (action === "perm-delete") {
      if (confirm(`Permanently delete "${f.file_name}"? This cannot be undone.`)) {
        await DB.permanentlyDeleteFile(fileId);
        if (S.selectedFileId === fileId) S.selectedFileId = null;
        CV.toast("File permanently deleted.");
        renderAll();
      }
    }
  }

  function doDownload(fileId) {
    const a = document.createElement("a");
    a.href = DB.downloadUrl(fileId);
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(async () => { await DB.refresh(); renderDetail(); }, 700);
  }

  // ---------------- bulk toolbar ----------------
  CV.qs("#bulkClear").addEventListener("click", () => { S.checked.clear(); renderAll(); });
  CV.qs("#bulkDownload").addEventListener("click", () => { S.checked.forEach((id) => doDownload(id)); });
  CV.qs("#bulkDelete").addEventListener("click", async () => {
    const ids = Array.from(S.checked);
    if (S.view === "trash") {
      if (!confirm(`Permanently delete ${ids.length} file(s)? This cannot be undone.`)) return;
      for (const id of ids) await DB.permanentlyDeleteFile(id);
      CV.toast("Files permanently deleted.");
    } else {
      for (const id of ids) await DB.softDeleteFile(id);
      CV.toast(`Moved ${ids.length} file(s) to trash.`);
    }
    if (ids.includes(S.selectedFileId)) S.selectedFileId = null;
    S.checked.clear(); renderAll();
  });
  CV.qs("#bulkMove").addEventListener("click", () => openMoveModal(Array.from(S.checked)));
  CV.qs("#bulkTag").addEventListener("click", () => { CV.qs("#bulkTagInput").value = ""; CV.qs("#bulkTagModal").classList.add("show"); });
  CV.qs("#confirmBulkTagBtn").addEventListener("click", async () => {
    const name = CV.qs("#bulkTagInput").value.trim();
    if (!name) return;
    for (const id of S.checked) await DB.addTagToFile(id, name);
    closeModal("bulkTagModal");
    CV.toast(`Tagged ${S.checked.size} file(s) "${name}".`, "ok");
    S.checked.clear(); renderAll();
  });

  // ---------------- modals ----------------
  function closeModal(id) { CV.qs("#" + id).classList.remove("show"); }
  CV.qsa("[data-close]").forEach((el) => el.addEventListener("click", () => closeModal(el.dataset.close)));
  CV.qsa(".modal-overlay").forEach((ov) => ov.addEventListener("click", (e) => { if (e.target === ov) ov.classList.remove("show"); }));

  // New folder
  CV.qs("#openNewFolder").addEventListener("click", () => {
    CV.qs("#folderNameInput").value = "";
    CV.qs("#folderError").style.display = "none";
    CV.qs("#folderModal").classList.add("show");
  });
  CV.qs("#createFolderBtn").addEventListener("click", async () => {
    const name = CV.qs("#folderNameInput").value.trim();
    if (!name) return;
    try {
      await DB.createFolder(name, S.view === "mine" ? S.folderId : null);
      closeModal("folderModal");
      CV.toast(`Folder "${name}" created.`, "ok");
      S.view = "mine"; S.groupId = null;
      renderAll();
    } catch (err) {
      const e = CV.qs("#folderError"); e.textContent = err.message; e.style.display = "block";
    }
  });

  // Move
  let moveTargets = [];
  function openMoveModal(fileIds) {
    moveTargets = fileIds;
    const sel = CV.qs("#moveFolderSelect");
    const opts = [`<option value="">My Files (root)</option>`].concat(
      DB.listAllFoldersForUser(user.user_id).map((x) => `<option value="${x.folder.folder_id}">${"— ".repeat(x.depth)}${CV.escapeHtml(x.folder.folder_name)}</option>`)
    );
    sel.innerHTML = opts.join("");
    CV.qs("#moveModal").classList.add("show");
  }
  CV.qs("#confirmMoveBtn").addEventListener("click", async () => {
    const val = CV.qs("#moveFolderSelect").value;
    const folderId = val ? Number(val) : null;
    for (const id of moveTargets) await DB.moveFile(id, folderId);
    closeModal("moveModal");
    CV.toast(`Moved ${moveTargets.length} item(s).`, "ok");
    S.checked.clear();
    renderAll();
  });

  // Rename
  let renameTarget = null;
  function openRenameModal(fileId) {
    renameTarget = fileId;
    CV.qs("#renameInput").value = DB.getFile(fileId).file_name;
    CV.qs("#renameModal").classList.add("show");
  }
  CV.qs("#confirmRenameBtn").addEventListener("click", async () => {
    const name = CV.qs("#renameInput").value.trim();
    if (!name || !renameTarget) return;
    await DB.renameFile(renameTarget, name);
    closeModal("renameModal");
    CV.toast("Renamed.", "ok");
    renderAll();
  });

  // Upload
  const dropzone = CV.qs("#dropzone");
  const fileInput = CV.qs("#fileInput");
  CV.qs("#openUpload").addEventListener("click", () => { CV.qs("#uploadList").innerHTML = ""; CV.qs("#uploadModal").classList.add("show"); });
  dropzone.addEventListener("dragover", (e) => { e.preventDefault(); dropzone.classList.add("drag"); });
  dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag"));
  dropzone.addEventListener("drop", (e) => {
    e.preventDefault(); dropzone.classList.remove("drag");
    handleFiles(e.dataTransfer.files);
  });
  fileInput.addEventListener("change", () => { handleFiles(fileInput.files); fileInput.value = ""; });

  async function handleFiles(fileList) {
    const list = CV.qs("#uploadList");
    const targetFolder = S.view === "mine" ? S.folderId : null;
    for (const file of Array.from(fileList)) {
      const row = document.createElement("div");
      row.className = "upload-file-row";
      row.innerHTML = `<span>${CV.escapeHtml(file.name)} <span class="meta-muted">(${CV.formatBytes(file.size)})</span></span><span class="upload-status">uploading…</span>`;
      list.prepend(row);
      const statusEl = row.querySelector(".upload-status");
      try {
        const r = await DB.uploadFile(file, targetFolder);
        statusEl.textContent = r.duplicate ? "duplicate content — storage reused" : (r.version_no > 1 ? `saved as version ${r.version_no}` : "uploaded");
        statusEl.className = "upload-status " + (r.duplicate ? "dup" : "ok");
      } catch (err) {
        statusEl.textContent = "failed: " + err.message;
      }
    }
    renderAll();
  }

  // ---------------- search / sort ----------------
  let searchDebounce = null;
  CV.qs("#searchInput").addEventListener("input", (e) => {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(() => { S.search = e.target.value; renderAll(); }, 120);
  });
  CV.qsa("thead th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      if (S.sortKey === th.dataset.sort) S.sortDir = S.sortDir === "asc" ? "desc" : "asc";
      else { S.sortKey = th.dataset.sort; S.sortDir = "asc"; }
      renderAll();
    });
  });
  CV.qs("#sortBtn").addEventListener("click", () => {
    const order = ["name", "modified", "size"];
    S.sortKey = order[(order.indexOf(S.sortKey) + 1) % order.length];
    renderAll();
  });

  // ---------------- sidebar nav ----------------
  CV.qsa(".sidebar .nav-item[data-view]").forEach((el) => {
    el.addEventListener("click", () => {
      S.view = el.dataset.view; S.groupId = null; S.folderId = null; S.selectedFileId = null; S.search = "";
      CV.qs("#searchInput").value = "";
      renderAll();
    });
  });
  CV.qs("#selectAllChk").addEventListener("click", () => {
    const files = currentFiles();
    const allChecked = files.length > 0 && files.every((f) => S.checked.has(f.file_id));
    if (allChecked) files.forEach((f) => S.checked.delete(f.file_id));
    else files.forEach((f) => S.checked.add(f.file_id));
    renderAll();
  });

  // ---------------- detail panel ----------------
  function tagEditorHtml(fileId) {
    const tags = DB.fileTags(fileId);
    return tags.map((t) => `<span class="tag-chip">${CV.escapeHtml(t.tag_name)}<button data-remove-tag="${t.tag_id}" aria-label="Remove tag ${CV.escapeHtml(t.tag_name)}">${ICON("x", 10)}</button></span>`).join("")
      + `<input class="tag-add-input" placeholder="+ tag" data-add-tag="${fileId}">`;
  }

  function versionsTabHtml(f) {
    const versions = DB.fileVersions(f.file_id).slice().reverse();
    const items = versions.map((v, i) => {
      const isCurrent = i === 0;
      const isDup = DB.findVersionByChecksum(v.checksum) !== v;
      return `<div class="ledger-item ${isCurrent ? "current" : ""} ${isDup ? "dup" : ""}">
        <div class="ledger-node"></div>
        <div class="ledger-row"><span class="ledger-ver">v${v.version_no}${isCurrent ? " — current" : ""}</span><span class="ledger-when">${CV.formatDateTime(v.uploaded_at)}</span></div>
        <div class="ledger-meta">Uploaded by ${v.uploaded_by === user.user_id ? "you" : CV.escapeHtml(DB.getUser(v.uploaded_by).name)} · ${CV.formatBytes(v.size_bytes)} ${isDup ? '<span class="badge badge-dup">checksum match</span>' : ""}</div>
        <div class="ledger-hash" title="sha256 ${v.checksum}">sha256 ${v.checksum}</div>
        ${!isCurrent ? `<span class="ledger-restore" data-restore-version="${v.version_id}">Restore this version</span>` : ""}
      </div>`;
    }).join("");
    return `<div class="ledger">${items}</div>
      <button class="btn btn-sm" id="uploadNewVersionBtn" style="width:100%;margin-top:16px;">${ICON("upload", 13)}Upload new version</button>
      <input type="file" id="newVersionInput" style="display:none;">`;
  }

  function accessTabHtml(f) {
    const perms = DB.filePermissions(f.file_id);
    const permRows = perms.map((p) => {
      const name = p.subject ? (p.subject.name || p.subject.group_name) : "Unknown";
      const sub = p.kind === "user" ? (p.subject ? p.subject.email : "") : `Group · ${p.subject ? DB.listGroupMembers(p.subject.group_id).length : 0} members`;
      const isOwner = p.permission_type === "Owner";
      return `<div class="perm-row">
        <div class="perm-who"><div class="avatar" style="margin:0;">${CV.escapeHtml(CV.initials(name))}</div><div><div class="perm-name">${CV.escapeHtml(name)}${p.subject && p.subject.user_id === user.user_id ? " (you)" : ""}</div><div class="perm-sub">${CV.escapeHtml(sub)}</div></div></div>
        ${isOwner ? '<span class="perm-pill perm-owner">Owner</span>' : `
        <div class="perm-actions">
          <select class="perm-select" data-perm-kind="${p.kind}" data-perm-subject="${p.subject ? (p.subject.user_id || p.subject.group_id) : ""}">
            <option value="Editor" ${p.permission_type === "Editor" ? "selected" : ""}>Editor</option>
            <option value="Viewer" ${p.permission_type === "Viewer" ? "selected" : ""}>Viewer</option>
            <option value="Remove">Remove access</option>
          </select>
        </div>`}
      </div>`;
    }).join("");

    const existingUserIds = new Set(perms.filter((p) => p.kind === "user").map((p) => p.subject && p.subject.user_id));
    const candidateUsers = DB.listUsers().filter((u) => u.user_id !== f.owner_id && !existingUserIds.has(u.user_id));
    const existingGroupIds = new Set(perms.filter((p) => p.kind === "group").map((p) => p.subject && p.subject.group_id));
    const candidateGroups = DB.listGroups().filter((g) => !existingGroupIds.has(g.group_id));

    return `${permRows}
      <div class="add-perm-row">
        <select id="addPermSubject">
          <optgroup label="People">${candidateUsers.map((u) => `<option value="user:${u.user_id}">${CV.escapeHtml(u.name)}</option>`).join("")}</optgroup>
          <optgroup label="Groups">${candidateGroups.map((g) => `<option value="group:${g.group_id}">${CV.escapeHtml(g.group_name)}</option>`).join("")}</optgroup>
        </select>
        <select id="addPermRole" style="max-width:90px;"><option>Editor</option><option>Viewer</option></select>
        <button class="btn btn-sm btn-primary" id="addPermBtn">Grant</button>
      </div>`;
  }

  function shareTabHtml(f) {
    const links = DB.fileShareLinks(f.file_id);
    const cards = links.map((l) => {
      const expired = l.expiry_date && new Date(l.expiry_date) < new Date();
      const maxed = l.max_downloads && l.download_count >= l.max_downloads;
      return `<div class="share-card">
        <div class="share-link-row">
          <input value="cloudvault.app/s/${l.token}" readonly>
          <button class="btn btn-sm" data-copy-link="${l.token}">Copy</button>
        </div>
        <div class="share-meta">
          <span>${l.expiry_date ? `Expires <b>${new Date(l.expiry_date).toLocaleDateString()}</b>${expired ? ' <span class="badge badge-danger">expired</span>' : ""}` : "No expiry"}</span>
          <span>Downloads <b>${l.download_count}${l.max_downloads ? " / " + l.max_downloads : ""}</b>${maxed ? ' <span class="badge badge-danger">limit reached</span>' : ""}</span>
          <span class="menu-item danger" style="padding:0;cursor:pointer;" data-revoke-link="${l.link_id}">Revoke</span>
        </div>
      </div>`;
    }).join("");
    return `${cards}
      <div class="share-new-form">
        <div class="field"><label>Expires (optional)</label><input type="date" id="newLinkExpiry"></div>
        <div class="field"><label>Max downloads</label><input type="number" id="newLinkMax" min="1" placeholder="∞"></div>
      </div>
      <button class="btn" style="width:100%;" id="createLinkBtn">+ Create new link</button>`;
  }

  function activityTabHtml(f) {
    const items = DB.fileActivity(f.file_id);
    if (!items.length) return `<div class="empty-state" style="padding:30px 10px;"><div class="sub">No activity yet.</div></div>`;
    return items.map((a) => `<div class="activity-item">
      <div class="activity-dot ${ACTION_DOT[a.action_type] || "dot-mod"}"></div>
      <div><div class="activity-text"><b>${a.user_id === user.user_id ? "You" : CV.escapeHtml(DB.getUser(a.user_id).name)}</b> ${CV.escapeHtml(a.details)}</div><div class="activity-time">${CV.formatDateTime(a.action_time)}</div></div>
    </div>`).join("");
  }

  let detailTab = "versions";
  function renderDetail() {
    const panel = CV.qs("#detailPanel");
    const appEl = CV.qs("#app");
    const f = S.selectedFileId ? DB.getFile(S.selectedFileId) : null;
    if (!f) { appEl.classList.add("no-detail"); panel.innerHTML = ""; return; }
    appEl.classList.remove("no-detail");
    const v = DB.currentVersion(f.file_id);
    const glyph = CV.fileGlyph(f.file_name);
    const owner = DB.getUser(f.owner_id);
    const inTrash = f.is_deleted;

    panel.innerHTML = `
      <div class="detail-head">
        <button class="detail-close" id="detailClose" title="Close" aria-label="Close">${ICON("x", 14)}</button>
        <div class="detail-glyph-row">
          <div class="file-glyph ${glyph.cls}" style="width:34px;height:34px;font-size:11px;">${glyph.label}</div>
          <div>
            <div class="detail-title">${CV.escapeHtml(f.file_name)}</div>
            <div class="detail-sub">${v ? CV.formatBytes(v.size_bytes) : ""} · Modified ${v ? CV.timeAgo(v.uploaded_at) : CV.timeAgo(f.created_at)} by ${owner.user_id === user.user_id ? "you" : CV.escapeHtml(owner.name)}</div>
          </div>
        </div>
        ${!inTrash ? `<div class="detail-tags" id="tagEditor">${tagEditorHtml(f.file_id)}</div>` : ""}
        <div class="detail-actions">
          ${inTrash ? `
            <button class="btn btn-primary" id="detailRestore">${ICON("restore", 15)}Restore</button>
            <button class="btn btn-danger" id="detailPermDelete">${ICON("trash", 15)}Delete</button>
          ` : `
            <button class="btn btn-primary" id="detailDownload">${ICON("download", 15)}Download</button>
            <button class="btn" id="detailShare">${ICON("share", 15)}Share</button>
            <div class="menu-wrap"><button class="btn" id="detailMoreBtn" aria-label="More actions">${ICON("more", 15)}</button><div class="menu" id="detailMoreMenu">${rowMenuHtml(f)}</div></div>
          `}
        </div>
      </div>
      ${!inTrash ? `
      <div class="tabs">
        <div class="tab ${detailTab === "versions" ? "active" : ""}" data-tab="versions">Versions</div>
        <div class="tab ${detailTab === "permissions" ? "active" : ""}" data-tab="permissions">Access</div>
        <div class="tab ${detailTab === "share" ? "active" : ""}" data-tab="share">Share links</div>
        <div class="tab ${detailTab === "activity" ? "active" : ""}" data-tab="activity">Activity</div>
      </div>
      <div class="tab-panel active" id="tabContent"></div>
      ` : `<div class="tab-panel active">${activityTabHtml(f)}</div>`}
    `;
    CV.qs("#detailClose").addEventListener("click", () => { S.selectedFileId = null; renderAll(); });

    if (!inTrash) {
      renderTabContent(f);
      CV.qsa(".tabs .tab").forEach((t) => t.addEventListener("click", () => { detailTab = t.dataset.tab; renderDetail(); }));
      CV.qs("#detailDownload").addEventListener("click", () => doDownload(f.file_id));
      CV.qs("#detailShare").addEventListener("click", () => { detailTab = "share"; renderDetail(); });
      CV.qs("#detailMoreBtn").addEventListener("click", (e) => { e.stopPropagation(); CV.qs("#detailMoreMenu").classList.toggle("show"); });
      CV.qsa("#detailMoreMenu .menu-item").forEach((item) => item.addEventListener("click", () => { CV.qs("#detailMoreMenu").classList.remove("show"); handleRowAction(f.file_id, item.dataset.act); }));

      const editor = CV.qs("#tagEditor");
      CV.qsa("[data-remove-tag]", editor).forEach((btn) => btn.addEventListener("click", async () => { await DB.removeTagFromFile(f.file_id, Number(btn.dataset.removeTag)); renderAll(); }));
      const addTagInput = CV.qs("[data-add-tag]", editor);
      addTagInput.addEventListener("keydown", async (e) => {
        if (e.key === "Enter" && addTagInput.value.trim()) { await DB.addTagToFile(f.file_id, addTagInput.value.trim()); renderAll(); }
      });
    } else {
      CV.qs("#detailRestore").addEventListener("click", () => handleRowAction(f.file_id, "restore"));
      CV.qs("#detailPermDelete").addEventListener("click", () => handleRowAction(f.file_id, "perm-delete"));
    }
  }

  function renderTabContent(f) {
    const el = CV.qs("#tabContent");
    if (detailTab === "versions") {
      el.innerHTML = versionsTabHtml(f);
      CV.qsa("[data-restore-version]").forEach((btn) => btn.addEventListener("click", async () => {
        await DB.restoreVersion(f.file_id, Number(btn.dataset.restoreVersion));
        CV.toast("Version restored.", "ok");
        renderAll();
      }));
      CV.qs("#uploadNewVersionBtn").addEventListener("click", () => CV.qs("#newVersionInput").click());
      CV.qs("#newVersionInput").addEventListener("change", async (e) => {
        const file = e.target.files[0]; if (!file) return;
        const r = await DB.uploadVersion(f.file_id, file);
        CV.toast(`Uploaded version ${r.version_no}.`, "ok");
        renderAll();
      });
    } else if (detailTab === "permissions") {
      el.innerHTML = accessTabHtml(f);
      CV.qsa(".perm-select", el).forEach((sel) => sel.addEventListener("change", async () => {
        const kind = sel.dataset.permKind, subj = Number(sel.dataset.permSubject);
        if (sel.value === "Remove") {
          if (kind === "user") await DB.revokeUserPermission(f.file_id, subj);
          else await DB.revokeGroupPermission(f.file_id, subj);
        } else {
          if (kind === "user") await DB.grantUserPermission(f.file_id, subj, sel.value);
          else await DB.grantGroupPermission(f.file_id, subj, sel.value);
        }
        renderAll();
      }));
      const addBtn = CV.qs("#addPermBtn");
      if (addBtn) addBtn.addEventListener("click", async () => {
        const val = CV.qs("#addPermSubject").value; if (!val) return;
        const [kind, id] = val.split(":");
        const role = CV.qs("#addPermRole").value;
        if (kind === "user") await DB.grantUserPermission(f.file_id, Number(id), role);
        else await DB.grantGroupPermission(f.file_id, Number(id), role);
        CV.toast("Access granted.", "ok");
        renderAll();
      });
    } else if (detailTab === "share") {
      el.innerHTML = shareTabHtml(f);
      CV.qsa("[data-copy-link]", el).forEach((btn) => btn.addEventListener("click", () => {
        navigator.clipboard?.writeText(`cloudvault.app/s/${btn.dataset.copyLink}`).catch(() => {});
        CV.toast("Link copied to clipboard.", "ok");
      }));
      CV.qsa("[data-revoke-link]", el).forEach((btn) => btn.addEventListener("click", async () => { await DB.revokeShareLink(Number(btn.dataset.revokeLink)); renderAll(); }));
      const createBtn = CV.qs("#createLinkBtn");
      if (createBtn) createBtn.addEventListener("click", async () => {
        const expiryVal = CV.qs("#newLinkExpiry").value;
        const maxVal = CV.qs("#newLinkMax").value;
        await DB.createShareLink(f.file_id, expiryVal ? new Date(expiryVal).toISOString() : null, maxVal ? Number(maxVal) : null);
        CV.toast("Share link created.", "ok");
        renderAll();
      });
    } else if (detailTab === "activity") {
      el.innerHTML = activityTabHtml(f);
    }
  }

  // ---------------- render root ----------------
  function renderAll() {
    renderSidebar();
    renderCrumb();
    renderTable();
    renderDetail();
  }

  renderAll();
})();
