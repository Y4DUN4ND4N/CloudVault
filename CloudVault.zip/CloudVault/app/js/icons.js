/* One icon set, one stroke voice (Lucide-style geometry, 1.75 stroke).
 * Replaces the emoji that were standing in for icons — emoji render
 * differently on every OS and break the page's typographic system.
 */
(function (global) {
  const P = {
    folder:      '<path d="M3 7.5A2 2 0 0 1 5 5.5h3.7a2 2 0 0 1 1.6.8l1.1 1.4H19a2 2 0 0 1 2 2v7.3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    folderPlus:  '<path d="M3 7.5A2 2 0 0 1 5 5.5h3.7a2 2 0 0 1 1.6.8l1.1 1.4H19a2 2 0 0 1 2 2v7.3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11.5v5"/><path d="M9.5 14h5"/>',
    users:       '<path d="M16 20v-1.6a3.4 3.4 0 0 0-3.4-3.4H6.4A3.4 3.4 0 0 0 3 18.4V20"/><circle cx="9.5" cy="8" r="3.4"/><path d="M21 20v-1.6a3.4 3.4 0 0 0-2.6-3.3"/><path d="M15.5 4.8a3.4 3.4 0 0 1 0 6.4"/>',
    link:        '<path d="M10.5 13.5a4 4 0 0 0 6 .4l2.4-2.4a4 4 0 0 0-5.6-5.7L12 7"/><path d="M13.5 10.5a4 4 0 0 0-6-.4l-2.4 2.4a4 4 0 0 0 5.6 5.7L12 17"/>',
    tag:         '<path d="M12.3 3.3a1.7 1.7 0 0 0-1.2-.5H4.5a1.7 1.7 0 0 0-1.7 1.7v6.6c0 .5.2.9.5 1.2l7.4 7.4a2 2 0 0 0 2.9 0l5.6-5.6a2 2 0 0 0 0-2.9z"/><circle cx="7.3" cy="7.3" r="1.1"/>',
    trash:       '<path d="M3.5 6.2h17"/><path d="M8.5 6.2V4.6a1.3 1.3 0 0 1 1.3-1.3h4.4a1.3 1.3 0 0 1 1.3 1.3v1.6"/><path d="M18.6 6.2 17.8 19a1.8 1.8 0 0 1-1.8 1.7H8a1.8 1.8 0 0 1-1.8-1.7L5.4 6.2"/>',
    upload:      '<path d="M20.5 15.2v3.4a1.8 1.8 0 0 1-1.8 1.8H5.3a1.8 1.8 0 0 1-1.8-1.8v-3.4"/><path d="M16.6 8.1 12 3.5 7.4 8.1"/><path d="M12 3.5v11.7"/>',
    download:    '<path d="M20.5 15.2v3.4a1.8 1.8 0 0 1-1.8 1.8H5.3a1.8 1.8 0 0 1-1.8-1.8v-3.4"/><path d="M7.4 10.4 12 15l4.6-4.6"/><path d="M12 15V3.3"/>',
    pencil:      '<path d="M16.6 3.6a2.1 2.1 0 0 1 3 3L7.7 18.5l-4 1 1-4z"/>',
    arrowRight:  '<path d="M4.5 12h15"/><path d="M13.2 5.4 19.8 12l-6.6 6.6"/>',
    copy:        '<rect x="9" y="9" width="11.5" height="11.5" rx="1.9"/><path d="M5.6 15H4.9A1.9 1.9 0 0 1 3 13.1V5.4a1.9 1.9 0 0 1 1.9-1.9h7.7A1.9 1.9 0 0 1 14.5 5.4V6"/>',
    restore:     '<path d="M3.4 12a8.6 8.6 0 1 0 2.7-6.3L3.3 8.2"/><path d="M3.3 3.6v4.6h4.6"/>',
    plus:        '<path d="M12 4.8v14.4"/><path d="M4.8 12h14.4"/>',
    search:      '<circle cx="10.8" cy="10.8" r="7.1"/><path d="M20.3 20.3 16 16"/>',
    sort:        '<path d="M7 3.8v16.4"/><path d="M3.4 7.4 7 3.8l3.6 3.6"/><path d="M17 20.2V3.8"/><path d="M20.6 16.6 17 20.2l-3.6-3.6"/>',
    more:        '<circle cx="5.2" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="18.8" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
    x:           '<path d="M18 6 6 18"/><path d="M6 6l12 12"/>',
    check:       '<path d="M20 6.5 9.2 17.3 4 12.1"/>',
    shield:      '<path d="M12 20.8s7.4-3.7 7.4-9.2V5.3L12 2.6 4.6 5.3v6.3c0 5.5 7.4 9.2 7.4 9.2z"/>',
    file:        '<path d="M13.7 3.2H6.9a1.9 1.9 0 0 0-1.9 1.9v13.8a1.9 1.9 0 0 0 1.9 1.9h10.2a1.9 1.9 0 0 0 1.9-1.9V8.4z"/><path d="M13.7 3.2v5.2h5.3"/>',
    logOut:      '<path d="M9.2 20.5H5.3a1.9 1.9 0 0 1-1.9-1.9V5.4a1.9 1.9 0 0 1 1.9-1.9h3.9"/><path d="M15.8 16.6 20.4 12l-4.6-4.6"/><path d="M20.4 12H9.2"/>',
    inbox:       '<path d="M20.6 12.4h-4.9l-1.5 2.4H9.8l-1.5-2.4H3.4"/><path d="M6.4 5.2 3.4 11.5v5.9a1.9 1.9 0 0 0 1.9 1.9h13.4a1.9 1.9 0 0 0 1.9-1.9v-5.9l-3-6.3a1.9 1.9 0 0 0-1.7-1.1H8.1a1.9 1.9 0 0 0-1.7 1.1z"/>',
    clock:       '<circle cx="12" cy="12" r="8.6"/><path d="M12 6.9V12l3.4 1.9"/>',
    share:       '<circle cx="17.5" cy="5.9" r="2.6"/><circle cx="6.5" cy="12" r="2.6"/><circle cx="17.5" cy="18.1" r="2.6"/><path d="M8.8 10.7 15.2 7.2"/><path d="M8.8 13.3l6.4 3.5"/>',
    star:        '<path d="m12 3.5 2.6 5.4 5.9.9-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9-4.3-4.1 5.9-.9z"/>',
    key:         '<circle cx="8" cy="15.5" r="4.8"/><path d="M11.4 12.1 20.4 3.1"/><path d="M16.2 7.3l2.6 2.6"/>',
    database:    '<ellipse cx="12" cy="6.2" rx="7.6" ry="3"/><path d="M4.4 6.2v11.6c0 1.7 3.4 3 7.6 3s7.6-1.3 7.6-3V6.2"/><path d="M4.4 12c0 1.7 3.4 3 7.6 3s7.6-1.3 7.6-3"/>',
    menu:        '<path d="M3.8 6.5h16.4"/><path d="M3.8 12h16.4"/><path d="M3.8 17.5h16.4"/>',
    sun:         '<circle cx="12" cy="12" r="4.1"/><path d="M12 2.6v2.1"/><path d="M12 19.3v2.1"/><path d="M4.35 4.35 5.84 5.84"/><path d="M18.16 18.16l1.49 1.49"/><path d="M2.6 12h2.1"/><path d="M19.3 12h2.1"/><path d="M4.35 19.65 5.84 18.16"/><path d="M18.16 5.84l1.49-1.49"/>',
    moon:        '<path d="M20.8 13.4A8.6 8.6 0 1 1 10.6 3.2a6.7 6.7 0 0 0 10.2 10.2z"/>',
  };

  function icon(name, size) {
    const body = P[name];
    if (!body) return '';
    const s = size || 16;
    return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" `
         + `stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">`
         + `${body}</svg>`;
  }

  /* Fills any <span data-icon="folder"> in static markup, so HTML stays
   * readable instead of carrying inline path data. JS-generated markup
   * calls ICON() directly. */
  function hydrate(root) {
    (root || document).querySelectorAll('[data-icon]').forEach((el) => {
      const name = el.getAttribute('data-icon');
      const size = Number(el.getAttribute('data-icon-size')) || 16;
      if (P[name]) el.innerHTML = icon(name, size);
    });
  }

  global.ICON = icon;
  icon.names = Object.keys(P);
  icon.hydrate = hydrate;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => hydrate());
  } else {
    hydrate();
  }
})(window);
