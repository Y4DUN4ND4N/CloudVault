(function (global) {
  function formatBytes(bytes) {
    if (!bytes) return "0 B";
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0; let v = bytes;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i += 1; }
    return (i === 0 ? v : v.toFixed(v < 10 ? 2 : 1)) + " " + units[i];
  }

  function timeAgo(iso) {
    const d = new Date(iso);
    const diff = Math.max(0, Date.now() - d.getTime());
    const min = 60000, hr = 3600000, day = 86400000;
    if (diff < min) return "just now";
    if (diff < hr) return Math.floor(diff / min) + "m ago";
    if (diff < day) return Math.floor(diff / hr) + "h ago";
    if (diff < day * 2) return "Yesterday";
    if (diff < day * 30) return Math.floor(diff / day) + "d ago";
    return d.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  }

  function formatDateTime(iso) {
    return new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function initials(name) {
    return String(name).trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  }

  function fileGlyph(filename) {
    const ext = (filename.split(".").pop() || "").toLowerCase();
    const map = {
      pdf: ["PDF", "glyph-pdf"], doc: ["DOC", "glyph-doc"], docx: ["DOC", "glyph-doc"],
      sql: ["SQL", "glyph-doc"], txt: ["TXT", "glyph-doc"], md: ["MD", "glyph-doc"],
      xls: ["XLS", "glyph-xls"], xlsx: ["XLS", "glyph-xls"], csv: ["CSV", "glyph-xls"],
      zip: ["ZIP", "glyph-zip"], rar: ["ZIP", "glyph-zip"], tar: ["ZIP", "glyph-zip"], gz: ["ZIP", "glyph-zip"],
      png: ["PNG", "glyph-img"], jpg: ["JPG", "glyph-img"], jpeg: ["JPG", "glyph-img"], gif: ["GIF", "glyph-img"], svg: ["SVG", "glyph-img"],
    };
    const [label, cls] = map[ext] || [ext ? ext.slice(0, 3).toUpperCase() : "FILE", "glyph-doc"];
    return { label, cls };
  }

  let toastTimer = null;
  function toast(message, kind) {
    let el = document.getElementById("cv-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "cv-toast";
      el.className = "cv-toast";
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.className = "cv-toast show" + (kind ? " " + kind : "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.className = "cv-toast"; }, 2600);
  }

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }

  async function requireSession(redirectTo) {
    const user = await DB.init();
    if (!user) { window.location.href = redirectTo || "login.html"; return null; }
    return user;
  }

  function initTopnav() {
    const user = DB.currentUser();
    const nav = qs(".topnav .who");
    if (!nav) return;
    if (user) {
      const avatar = qs(".topnav .who .avatar");
      if (avatar) avatar.textContent = initials(user.name);
      const adminLink = qs(".topnav .links a[href='admin.html']");
      if (adminLink && user.role !== "Admin") adminLink.remove();
    }
    qsa(".topnav .who a[href='login.html']").forEach((a) => {
      a.addEventListener("click", async (e) => { e.preventDefault(); await DB.logout(); window.location.href = "login.html"; });
    });

    // Overflow menu for the page links (Files / Reports & Groups / Admin) —
    // only present on pages without their own sidebar drawer (reports, admin).
    const menuBtn = qs("#topnavMenuBtn");
    const menu = qs("#topnavMenu");
    if (menuBtn && menu && !menuBtn.dataset.bound) {
      menuBtn.dataset.bound = "1";
      menuBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const open = menu.classList.toggle("show");
        menuBtn.setAttribute("aria-expanded", String(open));
      });
      document.addEventListener("click", () => {
        menu.classList.remove("show");
        menuBtn.setAttribute("aria-expanded", "false");
      });
    }
  }

  /* ---------- theme ----------
   * The <head> script resolves the theme before first paint (stored choice,
   * else the OS preference) so there's no flash. This wires the toggles and
   * keeps the stored choice in sync. */
  const THEME_KEY = "cloudvault_theme";

  function currentTheme() {
    return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
  }

  function applyTheme(theme, persist) {
    document.documentElement.dataset.theme = theme;
    if (persist) { try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* private mode */ } }
    qsa("[data-theme-toggle]").forEach((btn) => {
      const goingDark = theme === "light";
      btn.innerHTML = window.ICON ? ICON(goingDark ? "moon" : "sun", 15) : "";
      btn.setAttribute("aria-label", goingDark ? "Switch to dark theme" : "Switch to light theme");
      btn.setAttribute("title", goingDark ? "Dark theme" : "Light theme");
      btn.setAttribute("aria-pressed", String(theme === "dark"));
    });
  }

  function toggleTheme() {
    applyTheme(currentTheme() === "dark" ? "light" : "dark", true);
  }

  function initTheme() {
    applyTheme(currentTheme(), false);
    qsa("[data-theme-toggle]").forEach((btn) => {
      if (btn.dataset.themeBound) return;
      btn.dataset.themeBound = "1";
      btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); toggleTheme(); });
    });
    // Follow the OS only while the user hasn't made an explicit choice.
    if (window.matchMedia) {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const onChange = (e) => {
        let stored = null;
        try { stored = localStorage.getItem(THEME_KEY); } catch (err) { /* ignore */ }
        if (!stored) applyTheme(e.matches ? "dark" : "light", false);
      };
      if (mq.addEventListener) mq.addEventListener("change", onChange);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initTheme);
  } else {
    initTheme();
  }

  global.CV = { formatBytes, timeAgo, formatDateTime, escapeHtml, initials, fileGlyph, toast, qs, qsa, requireSession, initTopnav, initTheme, toggleTheme, currentTheme };
})(window);
