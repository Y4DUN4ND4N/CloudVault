(function () {
  const tabs = CV.qsa(".auth-tabs .tab");
  const loginForm = CV.qs("#loginForm");
  const registerForm = CV.qs("#registerForm");
  const errorBox = CV.qs("#errorBox");

  function showError(msg) { errorBox.textContent = msg; errorBox.classList.add("show"); }
  function clearError() { errorBox.classList.remove("show"); }

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      loginForm.style.display = tab.dataset.target === "loginForm" ? "block" : "none";
      registerForm.style.display = tab.dataset.target === "registerForm" ? "block" : "none";
      clearError();
    });
  });

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearError();
    const email = CV.qs("#loginEmail").value.trim();
    const password = CV.qs("#loginPassword").value;
    try {
      await DB.login(email, password);
      window.location.href = "dashboard.html";
    } catch (err) {
      showError(err.message || "Incorrect email or password. Try again.");
    }
  });

  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearError();
    const name = CV.qs("#regName").value.trim();
    const email = CV.qs("#regEmail").value.trim();
    const role = CV.qs("#regRole").value;
    const password = CV.qs("#regPassword").value;
    try {
      await DB.register({ name, email, password, role });
      window.location.href = "dashboard.html";
    } catch (err) {
      showError(err.message);
    }
  });

  (async () => {
    // Already signed in? Skip straight to the dashboard.
    const existing = await DB.init();
    if (existing) { window.location.href = "dashboard.html"; return; }

    const demoList = CV.qs("#demoList");
    try {
      const res = await fetch("/api/demo-accounts");
      const accounts = await res.json();
      accounts.forEach((u) => {
        const row = document.createElement("div");
        row.className = "acct";
        row.innerHTML = `<span>${CV.escapeHtml(u.name)}</span><span class="mono">${CV.escapeHtml(u.email)} · ${u.role}</span>`;
        row.addEventListener("click", () => {
          tabs[0].click();
          CV.qs("#loginEmail").value = u.email;
          CV.qs("#loginPassword").value = "demo";
        });
        demoList.appendChild(row);
      });
    } catch (e) { /* backend not reachable yet — demo list just stays empty */ }
  })();
})();
