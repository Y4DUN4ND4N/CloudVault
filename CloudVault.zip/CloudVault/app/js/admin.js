(async () => {
  const user = await CV.requireSession();
  if (!user) return;
  CV.initTopnav();

  if (user.role !== "Admin") {
    CV.qs("#denied").style.display = "block";
    return;
  }
  CV.qs("#page").style.display = "block";

  const roleClass = { Admin: "role-admin", Faculty: "role-faculty", Student: "role-student" };

  function renderKpis() {
    const users = DB.listUsers();
    const totalFiles = users.reduce((s, u) => s + DB.allOwnedFiles(u.user_id).length, 0);
    const kpis = [
      { label: "Total users", value: String(users.length), note: `${users.filter((u) => u.role === "Admin").length} admin(s)` },
      { label: "Total storage used", value: CV.formatBytes(DB.systemStorageUsed()), note: "system-wide" },
      { label: "Groups", value: String(DB.listGroups().length), note: "active project/batch groups" },
      { label: "Total files", value: String(totalFiles), note: "not counting trash" },
    ];
    CV.qs("#kpiRow").innerHTML = kpis.map((k) => `
      <div class="kpi"><div class="kpi-label">${k.label}</div><div class="kpi-value">${k.value}</div><div class="kpi-note">${k.note}</div></div>`).join("");
  }

  function renderUsers() {
    CV.qs("#userRows").innerHTML = DB.listUsers().map((u) => {
      const used = DB.userStorageUsed(u.user_id);
      const pct = Math.min(100, (used / u.storage_quota_bytes) * 100);
      return `<tr>
        <td><div class="name-cell"><div class="av">${CV.escapeHtml(CV.initials(u.name))}</div><div><div>${CV.escapeHtml(u.name)}${u.user_id === user.user_id ? " (you)" : ""}</div><div class="muted mono" style="font-size:10.5px;">${CV.escapeHtml(u.email)}</div></div></div></td>
        <td>
          <select class="perm-select" data-role="${u.user_id}">
            <option ${u.role === "Student" ? "selected" : ""}>Student</option>
            <option ${u.role === "Faculty" ? "selected" : ""}>Faculty</option>
            <option ${u.role === "Admin" ? "selected" : ""}>Admin</option>
          </select>
        </td>
        <td><span class="bar-track"><span class="bar-fill" style="width:${Math.max(4, pct)}%;"></span></span><span class="mono muted">${CV.formatBytes(used)}</span></td>
        <td>
          <div class="quota-row">
            <input class="quota-input" type="number" min="1" data-quota="${u.user_id}" value="${(u.storage_quota_bytes / 1024 ** 3).toFixed(0)}">
            <span class="muted" style="font-size:11px;">GB</span>
          </div>
        </td>
        <td class="muted">${DB.allOwnedFiles(u.user_id).length}</td>
      </tr>`;
    }).join("");

    CV.qsa("[data-role]").forEach((sel) => sel.addEventListener("change", async () => {
      await DB.updateUserRole(Number(sel.dataset.role), sel.value);
      CV.toast("Role updated.", "ok");
      renderAll();
    }));
    CV.qsa("[data-quota]").forEach((input) => input.addEventListener("change", async () => {
      const gb = Math.max(1, Number(input.value) || 1);
      await DB.updateUserQuota(Number(input.dataset.quota), gb * 1024 ** 3);
      CV.toast("Quota updated.", "ok");
      renderAll();
    }));
  }

  function renderGroups() {
    CV.qs("#groupRows").innerHTML = DB.listGroups().map((g) => `
      <tr>
        <td>${CV.escapeHtml(g.group_name)}</td>
        <td class="muted">${CV.escapeHtml(DB.getUser(g.created_by).name)}</td>
        <td class="muted">${DB.listGroupMembers(g.group_id).length}</td>
        <td class="muted">${DB.filesSharedWithGroup(g.group_id).length}</td>
      </tr>`).join("") || `<tr><td colspan="4" class="muted">No groups yet.</td></tr>`;
  }

  function renderAll() { renderKpis(); renderUsers(); renderGroups(); }
  renderAll();
})();
