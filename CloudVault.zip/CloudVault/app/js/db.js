/*
 * CloudVault API client. Talks to the Flask + SQLite backend in server/app.py.
 * Read helpers below all operate on a cached `state` snapshot (the same
 * table-shaped JSON the mock used to keep in localStorage) so every
 * rendering function elsewhere in the app is unchanged. Mutating functions
 * are async: they call the API, then refresh the snapshot before returning.
 */
(function (global) {
  let state = null;
  let me = null;

  async function api(method, path, { json, form } = {}) {
    const opts = { method, credentials: "same-origin" };
    if (json !== undefined) {
      opts.headers = { "Content-Type": "application/json" };
      opts.body = JSON.stringify(json);
    }
    if (form !== undefined) opts.body = form;
    const res = await fetch(path, opts);
    if (!res.ok) {
      let msg = res.statusText;
      try { const j = await res.json(); if (j.error) msg = j.error; } catch (e) { /* ignore */ }
      throw new Error(msg);
    }
    const ct = res.headers.get("content-type") || "";
    return ct.includes("application/json") ? res.json() : null;
  }

  async function refresh() { state = await api("GET", "/api/snapshot"); }

  async function init() {
    try {
      me = await api("GET", "/api/session");
      await refresh();
    } catch (e) {
      me = null; state = null;
    }
    return me;
  }

  function currentUser() { return me; }

  async function login(email, password) {
    me = await api("POST", "/api/auth/login", { json: { email, password } });
    await refresh();
    return me;
  }
  async function register({ name, email, password, role }) {
    me = await api("POST", "/api/auth/register", { json: { name, email, password, role } });
    await refresh();
    return me;
  }
  async function logout() {
    try { await api("POST", "/api/auth/logout"); } catch (e) { /* ignore */ }
    me = null; state = null;
  }
  async function resetDemoData() { /* server-side reset isn't wired up; use server/seed.py */ }

  // ---------------- read helpers (operate on cached snapshot) ----------------
  function listUsers() { return state.users.slice(); }
  function getUser(id) { return state.users.find((u) => u.user_id === id) || null; }
  function getUserByEmail(email) {
    return state.users.find((u) => u.email.toLowerCase() === String(email).toLowerCase()) || null;
  }

  function listGroups() { return state.user_groups.slice(); }
  function getGroup(id) { return state.user_groups.find((g) => g.group_id === id) || null; }
  function listGroupMembers(groupId) {
    return state.group_members.filter((m) => m.group_id === groupId).map((m) => getUser(m.user_id)).filter(Boolean);
  }
  function listUserGroups(userId) {
    return state.group_members.filter((m) => m.user_id === userId).map((m) => getGroup(m.group_id)).filter(Boolean);
  }
  function filesSharedWithGroup(groupId) {
    return state.file_group_permissions.filter((p) => p.group_id === groupId).map((p) => getFile(p.file_id)).filter(Boolean);
  }

  function listFolders(ownerId, parentFolderId) {
    return state.folders.filter((f) => f.owner_id === ownerId && f.parent_folder_id === (parentFolderId ?? null));
  }
  function getFolder(id) { return state.folders.find((f) => f.folder_id === id) || null; }
  function folderPath(folderId) {
    const path = [];
    let f = getFolder(folderId);
    while (f) { path.unshift(f); f = f.parent_folder_id ? getFolder(f.parent_folder_id) : null; }
    return path;
  }
  function listAllFoldersForUser(userId) {
    const mine = state.folders.filter((f) => f.owner_id === userId);
    const byParent = new Map();
    mine.forEach((f) => {
      const key = f.parent_folder_id ?? "root";
      if (!byParent.has(key)) byParent.set(key, []);
      byParent.get(key).push(f);
    });
    const out = [];
    (function walk(parentKey, depth) {
      (byParent.get(parentKey) || []).forEach((f) => { out.push({ folder: f, depth }); walk(f.folder_id, depth + 1); });
    })("root", 0);
    return out;
  }

  function getFile(id) { return state.files.find((f) => f.file_id === id) || null; }
  function fileVersions(fileId) {
    return state.file_versions.filter((v) => v.file_id === fileId).sort((a, b) => a.version_no - b.version_no);
  }
  function currentVersion(fileId) {
    const vs = fileVersions(fileId);
    return vs.length ? vs[vs.length - 1] : null;
  }
  function findVersionByChecksum(checksum) {
    return state.file_versions.find((v) => v.checksum === checksum) || null;
  }
  function fileTags(fileId) {
    return state.file_tags.filter((t) => t.file_id === fileId).map((t) => state.tags.find((tg) => tg.tag_id === t.tag_id)).filter(Boolean);
  }
  function filePermissions(fileId) {
    const users = state.file_user_permissions.filter((p) => p.file_id === fileId).map((p) => ({ kind: "user", subject: getUser(p.user_id), permission_type: p.permission_type, granted_by: p.granted_by, granted_at: p.granted_at }));
    const groups = state.file_group_permissions.filter((p) => p.file_id === fileId).map((p) => ({ kind: "group", subject: getGroup(p.group_id), permission_type: p.permission_type, granted_by: p.granted_by, granted_at: p.granted_at }));
    return users.concat(groups);
  }
  function isSharedWithUser(fileId, userId) {
    if (state.file_user_permissions.some((p) => p.file_id === fileId && p.user_id === userId)) return true;
    const groupIds = listUserGroups(userId).map((g) => g.group_id);
    return state.file_group_permissions.some((p) => p.file_id === fileId && groupIds.includes(p.group_id));
  }
  function fileShareLinks(fileId) { return state.share_links.filter((s) => s.file_id === fileId); }
  function listAllShareLinks() { return state.share_links.slice(); }

  function fileActivity(fileId) {
    return state.activity_logs.filter((a) => a.file_id === fileId).sort((a, b) => new Date(b.action_time) - new Date(a.action_time));
  }
  function recentActivity(limit) {
    return state.activity_logs.slice().sort((a, b) => new Date(b.action_time) - new Date(a.action_time)).slice(0, limit || 20);
  }

  function allOwnedFiles(userId) { return state.files.filter((f) => !f.is_deleted && f.owner_id === userId); }

  function visibleFiles(userId, view, folderId, groupId) {
    let files = state.files.slice();
    if (view === "trash") {
      files = files.filter((f) => f.is_deleted && f.owner_id === userId);
    } else {
      files = files.filter((f) => !f.is_deleted);
      if (view === "mine") files = files.filter((f) => f.owner_id === userId && f.folder_id === (folderId ?? null));
      else if (view === "shared-with-me") files = files.filter((f) => f.owner_id !== userId && isSharedWithUser(f.file_id, userId));
      else if (view === "shared-by-me") files = files.filter((f) => f.owner_id === userId && (state.file_user_permissions.some((p) => p.file_id === f.file_id && p.user_id !== userId) || state.file_group_permissions.some((p) => p.file_id === f.file_id) || state.share_links.some((s) => s.file_id === f.file_id)));
      else if (view === "tagged") files = files.filter((f) => (f.owner_id === userId || isSharedWithUser(f.file_id, userId)) && fileTags(f.file_id).length > 0);
      else if (view === "group") files = files.filter((f) => state.file_group_permissions.some((p) => p.file_id === f.file_id && p.group_id === groupId) && (f.owner_id === userId || isSharedWithUser(f.file_id, userId)));
      else files = files.filter((f) => f.owner_id === userId || isSharedWithUser(f.file_id, userId));
    }
    return files;
  }
  function countFiles(userId, view) {
    if (view === "mine") return state.files.filter((f) => !f.is_deleted && f.owner_id === userId).length;
    return visibleFiles(userId, view).length;
  }
  function searchFiles(userId, query, view, folderId, groupId) {
    const q = (query || "").trim().toLowerCase();
    let files = visibleFiles(userId, view, folderId, groupId);
    if (!q) return files;
    return files.filter((f) => {
      const owner = getUser(f.owner_id);
      const tags = fileTags(f.file_id).map((t) => t.tag_name).join(" ");
      return f.file_name.toLowerCase().includes(q) || (owner && owner.name.toLowerCase().includes(q)) || tags.includes(q);
    });
  }
  function sortFiles(files, key, dir) {
    const mul = dir === "asc" ? 1 : -1;
    const arr = files.slice();
    arr.sort((a, b) => {
      if (key === "name") return mul * a.file_name.localeCompare(b.file_name);
      if (key === "size") return mul * ((currentVersion(a.file_id)?.size_bytes || 0) - (currentVersion(b.file_id)?.size_bytes || 0));
      if (key === "modified") {
        const am = currentVersion(a.file_id)?.uploaded_at || a.created_at;
        const bm = currentVersion(b.file_id)?.uploaded_at || b.created_at;
        return mul * (new Date(am) - new Date(bm));
      }
      return 0;
    });
    return arr;
  }

  function userStorageUsed(userId) {
    return state.files.filter((f) => !f.is_deleted && f.owner_id === userId).reduce((sum, f) => {
      const v = currentVersion(f.file_id);
      return sum + (v ? v.size_bytes : 0);
    }, 0);
  }
  function systemStorageUsed() { return state.users.reduce((sum, u) => sum + userStorageUsed(u.user_id), 0); }
  function dedupSavingsBytes() {
    const seenPaths = new Map();
    let savings = 0;
    state.file_versions.slice().sort((a, b) => new Date(a.uploaded_at) - new Date(b.uploaded_at)).forEach((v) => {
      if (seenPaths.has(v.storage_path)) savings += v.size_bytes;
      else seenPaths.set(v.storage_path, v);
    });
    return savings;
  }
  function duplicateGroups() {
    const byChecksum = new Map();
    state.file_versions.forEach((v) => {
      if (!byChecksum.has(v.checksum)) byChecksum.set(v.checksum, []);
      byChecksum.get(v.checksum).push(v);
    });
    const groups = [];
    byChecksum.forEach((versions, checksum) => {
      const fileIds = new Set(versions.map((v) => v.file_id));
      if (versions.length > 1) {
        groups.push({ checksum, versions: versions.sort((a, b) => new Date(a.uploaded_at) - new Date(b.uploaded_at)), files: Array.from(fileIds).map(getFile).filter(Boolean) });
      }
    });
    return groups;
  }

  // ---------------- mutations (call API, then refresh snapshot) ----------------
  async function updateUserRole(userId, role) { await api("PATCH", `/api/users/${userId}`, { json: { role } }); await refresh(); }
  async function updateUserQuota(userId, quotaBytes) { await api("PATCH", `/api/users/${userId}`, { json: { storage_quota_bytes: quotaBytes } }); await refresh(); }

  async function createGroup(name, description) {
    const r = await api("POST", "/api/groups", { json: { group_name: name, description } });
    await refresh();
    return getGroup(r.group_id);
  }
  async function addGroupMember(groupId, userId) { await api("POST", `/api/groups/${groupId}/members`, { json: { user_id: userId } }); await refresh(); }
  async function removeGroupMember(groupId, userId) { await api("DELETE", `/api/groups/${groupId}/members/${userId}`); await refresh(); }

  async function createFolder(name, parentFolderId) {
    const r = await api("POST", "/api/folders", { json: { folder_name: name, parent_folder_id: parentFolderId ?? null } });
    await refresh();
    return getFolder(r.folder_id);
  }

  async function uploadFile(file, folderId) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("folder_id", folderId ?? "");
    const r = await api("POST", "/api/files", { form: fd });
    await refresh();
    return r;
  }
  async function uploadVersion(fileId, file) {
    const fd = new FormData();
    fd.append("file", file);
    const r = await api("POST", `/api/files/${fileId}/versions`, { form: fd });
    await refresh();
    return r;
  }
  async function restoreVersion(fileId, versionId) { await api("POST", `/api/files/${fileId}/versions/${versionId}/restore`); await refresh(); }

  async function renameFile(fileId, name) { await api("PATCH", `/api/files/${fileId}`, { json: { file_name: name } }); await refresh(); }
  async function moveFile(fileId, folderId) { await api("PATCH", `/api/files/${fileId}`, { json: { folder_id: folderId ?? null } }); await refresh(); }
  async function copyFile(fileId) { const r = await api("POST", `/api/files/${fileId}/copy`); await refresh(); return r; }
  async function softDeleteFile(fileId) { await api("DELETE", `/api/files/${fileId}`); await refresh(); }
  async function restoreFile(fileId) { await api("POST", `/api/files/${fileId}/restore`); await refresh(); }
  async function permanentlyDeleteFile(fileId) { await api("DELETE", `/api/files/${fileId}/permanent`); await refresh(); }

  async function addTagToFile(fileId, name) { const r = await api("POST", `/api/files/${fileId}/tags`, { json: { tag_name: name } }); await refresh(); return r; }
  async function removeTagFromFile(fileId, tagId) { await api("DELETE", `/api/files/${fileId}/tags/${tagId}`); await refresh(); }

  async function grantUserPermission(fileId, userId, type) { await api("POST", `/api/files/${fileId}/permissions/user`, { json: { user_id: userId, permission_type: type } }); await refresh(); }
  async function revokeUserPermission(fileId, userId) { await api("DELETE", `/api/files/${fileId}/permissions/user/${userId}`); await refresh(); }
  async function grantGroupPermission(fileId, groupId, type) { await api("POST", `/api/files/${fileId}/permissions/group`, { json: { group_id: groupId, permission_type: type } }); await refresh(); }
  async function revokeGroupPermission(fileId, groupId) { await api("DELETE", `/api/files/${fileId}/permissions/group/${groupId}`); await refresh(); }

  async function createShareLink(fileId, expiryIso, maxDownloads) {
    const r = await api("POST", `/api/files/${fileId}/share-links`, { json: { expiry_date: expiryIso, max_downloads: maxDownloads } });
    await refresh();
    return r;
  }
  async function revokeShareLink(linkId) { await api("DELETE", `/api/share-links/${linkId}`); await refresh(); }

  function downloadUrl(fileId) { return `/api/files/${fileId}/download`; }

  global.DB = {
    init, refresh, currentUser, login, register, logout, resetDemoData,
    listUsers, getUser, getUserByEmail, updateUserRole, updateUserQuota,
    listGroups, getGroup, createGroup, listGroupMembers, listUserGroups, addGroupMember, removeGroupMember, filesSharedWithGroup,
    listFolders, getFolder, folderPath, createFolder, listAllFoldersForUser,
    getFile, fileVersions, currentVersion, fileTags, filePermissions, isSharedWithUser, findVersionByChecksum,
    uploadFile, uploadVersion, restoreVersion, renameFile, moveFile, copyFile, softDeleteFile, restoreFile, permanentlyDeleteFile,
    addTagToFile, removeTagFromFile,
    grantUserPermission, revokeUserPermission, grantGroupPermission, revokeGroupPermission,
    createShareLink, revokeShareLink, fileShareLinks, listAllShareLinks, downloadUrl,
    fileActivity, recentActivity,
    visibleFiles, countFiles, searchFiles, sortFiles, allOwnedFiles,
    userStorageUsed, dedupSavingsBytes, duplicateGroups, systemStorageUsed,
  };
})(window);
