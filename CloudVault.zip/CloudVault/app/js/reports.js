(async () => {
  const user = await CV.requireSession();
  if (!user) return;
  CV.initTopnav();

  const ACTION_DOT = { Upload: "dot-upload", Share: "dot-share", Modify: "dot-mod", Delete: "dot-del", Restore: "dot-restore", Download: "dot-share" };

  function countDuplicatesForUser(userId) {
    return DB.allOwnedFiles(userId).filter((f) => {
      const v = DB.currentVersion(f.file_id);
      return v && DB.findVersionByChecksum(v.checksum) !== v;
    }).length;
  }

  function allDeletedFilesCount() {
    return DB.listUsers().reduce((sum, u) => sum + (DB.countFiles(u.user_id, "trash")), 0);
  }

  function renderKpis() {
    const links = DB.listAllShareLinks();
    const expiringSoon = links.filter((l) => l.expiry_date && (new Date(l.expiry_date) - Date.now()) < 7 * 86400000 && (new Date(l.expiry_date) - Date.now()) > 0).length;
    const kpis = [
      { label: "Total storage used", value: CV.formatBytes(DB.systemStorageUsed()), note: `across ${DB.listUsers().length} users` },
      { label: "Saved via dedup", value: CV.formatBytes(DB.dedupSavingsBytes()), note: "avoided by checksum matching", up: true },
      { label: "Active share links", value: String(links.length), note: `${expiringSoon} expiring this week` },
      { label: "Files in recycle bin", value: String(allDeletedFilesCount()), note: "across all users" },
    ];
    CV.qs("#kpiRow").innerHTML = kpis.map((k) => `
      <div class="kpi">
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-value">${k.value}</div>
        <div class="kpi-note${k.up ? " up" : ""}">${k.note}</div>
      </div>`).join("");
  }

  function renderStorageTable() {
    const users = DB.listUsers();
    const usages = users.map((u) => DB.userStorageUsed(u.user_id));
    const max = Math.max(1, ...usages);
    const roleClass = { Admin: "role-admin", Faculty: "role-faculty", Student: "role-student" };
    CV.qs("#storageRows").innerHTML = users.map((u, i) => {
      const used = usages[i];
      const dups = countDuplicatesForUser(u.user_id);
      return `<tr>
        <td><div class="name-cell"><div class="av">${CV.escapeHtml(CV.initials(u.name))}</div>${CV.escapeHtml(u.name)}${u.user_id === user.user_id ? " (you)" : ""}</div></td>
        <td><span class="role-pill ${roleClass[u.role] || "role-student"}">${u.role}</span></td>
        <td><span class="bar-track"><span class="bar-fill" style="width:${Math.max(4, (used / max) * 100)}%;"></span></span><span class="mono muted">${CV.formatBytes(used)}</span></td>
        <td class="muted">${DB.allOwnedFiles(u.user_id).length}</td>
        <td>${dups ? `<span class="dup-badge">${dups} file${dups > 1 ? "s" : ""}</span>` : '<span class="muted">—</span>'}</td>
      </tr>`;
    }).join("");
  }

  function renderGroups() {
    const groups = DB.listGroups();
    CV.qs("#groupCards").innerHTML = groups.map((g) => {
      const members = DB.listGroupMembers(g.group_id);
      const fileCount = DB.filesSharedWithGroup(g.group_id).length;
      const avatars = members.slice(0, 4).map((m) => `<div class="av" title="${CV.escapeHtml(m.name)}">${CV.escapeHtml(CV.initials(m.name))}</div>`).join("");
      const extra = members.length > 4 ? `<div class="av">+${members.length - 4}</div>` : "";
      return `<div class="group-card">
        <div class="group-top"><div class="group-name" data-manage="${g.group_id}">${CV.escapeHtml(g.group_name)}</div><div class="group-count">${members.length} members · ${fileCount} files</div></div>
        <div class="group-members">${avatars}${extra}</div>
        <span class="group-manage-link" data-manage="${g.group_id}">Manage members${ICON("arrowRight", 12)}</span>
      </div>`;
    }).join("") || `<div class="panel-empty">No groups yet — create one above.</div>`;
    CV.qsa("[data-manage]").forEach((el) => el.addEventListener("click", () => openMembersModal(Number(el.dataset.manage))));
  }

  function renderActivity() {
    const items = DB.recentActivity(20);
    CV.qs("#activityFeed").innerHTML = items.map((a) => {
      const f = DB.getFile(a.file_id);
      return `<div class="log-item">
        <div class="log-dot ${ACTION_DOT[a.action_type] || "dot-mod"}"></div>
        <div><div class="log-text"><b>${a.user_id === user.user_id ? "You" : CV.escapeHtml(DB.getUser(a.user_id).name)}</b> ${CV.escapeHtml(a.details)}${f ? ` <span class="muted">— ${CV.escapeHtml(f.file_name)}</span>` : ""}</div><div class="log-time">${CV.formatDateTime(a.action_time)}</div></div>
      </div>`;
    }).join("") || `<div class="panel-empty">No activity yet.</div>`;
  }

  function renderDuplicates() {
    const groups = DB.duplicateGroups();
    if (!groups.length) { CV.qs("#dupFeed").innerHTML = `<div class="panel-empty">No duplicate content detected yet.</div>`; return; }
    CV.qs("#dupFeed").innerHTML = groups.map((g) => {
      const names = g.files.map((f) => CV.escapeHtml(f.file_name)).join(", ");
      return `<div class="log-item">
        <div><div class="log-text">${names} <span class="muted">— ${g.versions.length} versions share content</span></div><div class="log-time mono">sha256 ${g.checksum.slice(0, 12)}…</div></div>
      </div>`;
    }).join("");
  }

  function renderAll() {
    renderKpis(); renderStorageTable(); renderGroups(); renderActivity(); renderDuplicates();
  }

  // ---------------- new group ----------------
  function closeModal(id) { CV.qs("#" + id).classList.remove("show"); }
  CV.qsa("[data-close]").forEach((el) => el.addEventListener("click", () => closeModal(el.dataset.close)));
  CV.qsa(".modal-overlay").forEach((ov) => ov.addEventListener("click", (e) => { if (e.target === ov) ov.classList.remove("show"); }));

  CV.qs("#newGroupBtn").addEventListener("click", () => {
    CV.qs("#newGroupName").value = ""; CV.qs("#newGroupDesc").value = "";
    CV.qs("#newGroupModal").classList.add("show");
  });
  CV.qs("#createGroupBtn").addEventListener("click", async () => {
    const name = CV.qs("#newGroupName").value.trim();
    if (!name) return;
    try {
      await DB.createGroup(name, CV.qs("#newGroupDesc").value.trim());
      closeModal("newGroupModal");
      CV.toast(`Group "${name}" created.`, "ok");
      renderAll();
    } catch (err) {
      CV.toast(err.message, "err");
    }
  });

  // ---------------- manage members ----------------
  let activeGroupId = null;
  function openMembersModal(groupId) {
    activeGroupId = groupId;
    renderMembersModal();
    CV.qs("#membersModal").classList.add("show");
  }
  function renderMembersModal() {
    const g = DB.getGroup(activeGroupId);
    CV.qs("#membersModalTitle").textContent = g.group_name + " — members";
    const members = DB.listGroupMembers(activeGroupId);
    CV.qs("#memberRows").innerHTML = members.map((m) => `
      <div class="member-row">
        <div class="perm-who"><div class="avatar" style="margin:0;">${CV.escapeHtml(CV.initials(m.name))}</div><div><div class="perm-name">${CV.escapeHtml(m.name)}</div><div class="perm-sub">${CV.escapeHtml(m.email)}</div></div></div>
        ${m.user_id === g.created_by ? '<span class="perm-pill perm-owner">Creator</span>' : `<button class="btn btn-sm btn-danger" data-remove-member="${m.user_id}">Remove</button>`}
      </div>`).join("");
    CV.qsa("[data-remove-member]").forEach((btn) => btn.addEventListener("click", async () => {
      await DB.removeGroupMember(activeGroupId, Number(btn.dataset.removeMember));
      renderMembersModal(); renderAll();
    }));
    const candidates = DB.listUsers().filter((u) => !members.some((m) => m.user_id === u.user_id));
    CV.qs("#addMemberSelect").innerHTML = candidates.map((u) => `<option value="${u.user_id}">${CV.escapeHtml(u.name)}</option>`).join("") || `<option value="">No more users to add</option>`;
  }
  CV.qs("#addMemberBtn").addEventListener("click", async () => {
    const val = CV.qs("#addMemberSelect").value;
    if (!val) return;
    await DB.addGroupMember(activeGroupId, Number(val));
    renderMembersModal(); renderAll();
  });

  renderAll();
})();
