"""Reset the local demo to two accounts and empty libraries.

This explicitly clears existing accounts, groups, files, versions, permissions,
links, tags and activity. Run only when resetting the local demonstration.
"""
import os
import sqlite3
from pathlib import Path
from werkzeug.security import generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'cloudvault.db'
SCHEMA_PATH = BASE_DIR / 'schema.sql'


def seed():
    conn = sqlite3.connect(DB_PATH)
    conn.execute('PRAGMA foreign_keys=ON')
    conn.executescript(SCHEMA_PATH.read_text())
    try:
        conn.execute('BEGIN IMMEDIATE')
        for table in ('activity_logs', 'share_links', 'file_group_permissions',
                      'file_user_permissions', 'file_tags', 'file_versions',
                      'files', 'folders', 'group_members', 'user_groups', 'tags', 'users'):
            conn.execute(f'DELETE FROM {table}')
        # Keep ID sequences so previous signed-in sessions cannot become new users.
        conn.executemany(
            'INSERT INTO users (name,email,password_hash,role,storage_quota_bytes,storage_used_bytes) VALUES (?,?,?,?,?,0)',
            [('Test', 'test@college.edu', generate_password_hash('demo'), 'Student', 10 * 1024**3),
             ('Admin', 'admin@college.edu', generate_password_hash('demo'), 'Admin', 50 * 1024**3)],
        )
        violations = conn.execute('PRAGMA foreign_key_check').fetchall()
        if violations:
            raise RuntimeError('Foreign key check failed')
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    # Uploaded content is separate from metadata; clear the local objects too.
    uploads = BASE_DIR / 'uploads'
    if uploads.exists():
        for item in uploads.iterdir():
            if item.is_file() or item.is_symlink():
                item.unlink()
    print('Reset complete: Test and Admin accounts; no groups or files.')


if __name__ == '__main__':
    seed()
