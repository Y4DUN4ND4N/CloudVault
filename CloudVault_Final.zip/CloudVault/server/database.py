"""Connection adapter for the documented MySQL schema and local SQLite demo."""
import os
import re
from datetime import datetime, date


class MySQLCursor:
    def __init__(self, cursor):
        self.cursor = cursor
        self.lastrowid = cursor.lastrowid

    def fetchall(self):
        return [self.normalize(row) for row in self.cursor.fetchall()]

    def fetchone(self):
        row = self.cursor.fetchone()
        return self.normalize(row) if row else None

    def __iter__(self):
        return iter(self.fetchall())

    @staticmethod
    def normalize(row):
        return {key: value.isoformat() + ('Z' if isinstance(value, datetime) else '')
                if isinstance(value, (datetime, date)) else value for key, value in row.items()}


class MySQLConnection:
    def __init__(self):
        import pymysql
        self.connection = pymysql.connect(
            host=os.environ.get('MYSQL_HOST', '127.0.0.1'),
            port=int(os.environ.get('MYSQL_PORT', '3306')),
            user=os.environ['MYSQL_USER'], password=os.environ['MYSQL_PASSWORD'],
            database=os.environ.get('MYSQL_DATABASE', 'cloudvault'),
            charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor,
        )

    def execute(self, sql, params=()):
        sql = sql.replace('BEGIN IMMEDIATE', 'START TRANSACTION')
        sql = sql.replace('INSERT OR IGNORE', 'INSERT IGNORE')
        sql = re.sub(r'\bIS \?', '<=> ?', sql)
        sql = re.sub(r'ON CONFLICT\(file_id,(user_id|group_id)\) DO UPDATE SET permission_type=excluded.permission_type',
                     'ON DUPLICATE KEY UPDATE permission_type=VALUES(permission_type)', sql)
        sql = sql.replace('?', '%s')
        params = tuple(datetime.fromisoformat(value.replace('Z', '+00:00')).replace(tzinfo=None)
                       if isinstance(value, str) and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z', value)
                       else value for value in params)
        cursor = self.connection.cursor()
        cursor.execute(sql, params)
        return MySQLCursor(cursor)

    def commit(self): self.connection.commit()
    def rollback(self): self.connection.rollback()
    def close(self): self.connection.close()
