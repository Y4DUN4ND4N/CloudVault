import hashlib
import os
import secrets
import sqlite3
from datetime import datetime, timezone

from database import MySQLConnection
import storage

from werkzeug.security import generate_password_hash, check_password_hash

from flask import Flask, g, jsonify, request, session, send_from_directory, abort

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "cloudvault.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
APP_DIR = os.path.join(os.path.dirname(BASE_DIR), "app")

app = Flask(__name__, static_folder=None)
def session_secret():
    configured = os.environ.get("CLOUDVAULT_SECRET")
    if configured:
        return configured
    path = os.path.join(BASE_DIR, ".session-secret")
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        with open(path) as source:
            return source.read().strip()
    secret = secrets.token_hex(32)
    with os.fdopen(fd, "w") as output:
        output.write(secret)
    return secret


app.secret_key = session_secret()
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_db():
    if "db" not in g:
        if os.environ.get("DATABASE_BACKEND", "sqlite") == "mysql":
            g.db = MySQLConnection()
        else:
            g.db = sqlite3.connect(DB_PATH)
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
            columns = {r[1] for r in g.db.execute("PRAGMA table_info(users)")}
            if "password" in columns:
                g.db.execute("ALTER TABLE users RENAME COLUMN password TO password_hash")
                for row in g.db.execute("SELECT user_id,password_hash FROM users").fetchall():
                    g.db.execute("UPDATE users SET password_hash=? WHERE user_id=?", (generate_password_hash(row[1]), row[0]))
            if "storage_used_bytes" not in columns:
                g.db.execute("ALTER TABLE users ADD COLUMN storage_used_bytes INTEGER NOT NULL DEFAULT 0")
        sync_storage(g.db)
        g.db.commit()
    return g.db


def sync_storage(db):
    # Logical usage includes retained versions and trash; these still occupy storage.
    db.execute("""UPDATE users SET storage_used_bytes=COALESCE((
        SELECT SUM(v.size_bytes) FROM file_versions v JOIN files f USING(file_id)
        WHERE f.owner_id=users.user_id),0)""")


def file_access(file_id, level="Viewer", allow_deleted=False):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404, description="File not found.")
    rank = 3 if f["owner_id"] == user["user_id"] else 0
    for permission in db.execute("""SELECT permission_type FROM file_user_permissions WHERE file_id=? AND user_id=?
        UNION ALL SELECT p.permission_type FROM file_group_permissions p JOIN group_members m USING(group_id)
        WHERE p.file_id=? AND m.user_id=?""", (file_id,user["user_id"],file_id,user["user_id"])):
        rank = max(rank, {"Viewer":1,"Editor":2,"Owner":3}[permission["permission_type"]])
    # Ownership remains singular even if legacy rows contain additional Owner grants.
    if level == "Owner" and f["owner_id"] != user["user_id"]:
        abort(403, description="Only the file owner can manage sharing or deletion.")
    if rank < {"Viewer":1,"Editor":2,"Owner":3}[level]:
        abort(403, description="You do not have permission for this action.")
    if f["is_deleted"] and not allow_deleted:
        abort(409, description="Restore this file before using it.")
    return f


def owned_folder(folder_id, owner_id):
    if folder_id is not None and not one(get_db().execute(
        "SELECT 1 FROM folders WHERE folder_id=? AND owner_id=?", (folder_id,owner_id))):
        abort(400, description="Choose a folder owned by the file owner.")


def check_quota(owner_id, additional):
    db = get_db()
    sync_storage(db)
    owner = one(db.execute("SELECT * FROM users WHERE user_id=?", (owner_id,)))
    if owner["storage_used_bytes"] + additional > owner["storage_quota_bytes"]:
        abort(409, description="Storage quota exceeded. Permanently delete unused files or request more storage.")


@app.errorhandler(sqlite3.IntegrityError)
def constraint_error(error):
    get_db().rollback()
    return jsonify(error="This change conflicts with an existing name or database relationship."), 409


if os.environ.get("DATABASE_BACKEND", "sqlite") == "mysql":
    from pymysql import IntegrityError
    app.register_error_handler(IntegrityError, constraint_error)


@app.before_request
def authorize_resource():
    args = request.view_args or {}
    if "file_id" in args and request.path.startswith("/api/files/"):
        endpoint = request.endpoint
        level = "Viewer" if endpoint in ("download_file", "download_version", "copy_file") else "Editor"
        if endpoint in ("soft_delete_file", "restore_file", "permanent_delete_file", "grant_user_permission",
                        "revoke_user_permission", "grant_group_permission", "revoke_group_permission", "create_share_link"):
            level = "Owner"
        file_access(args["file_id"], level, endpoint in ("restore_file", "permanent_delete_file"))
    if request.endpoint in ("add_member", "remove_member"):
        user = require_user()
        group = one(get_db().execute("SELECT * FROM user_groups WHERE group_id=?", (args["group_id"],)))
        if not group:
            abort(404)
        if group["created_by"] != user["user_id"] and user["role"] != "Admin":
            abort(403, description="Only the group creator or an administrator can manage members.")


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    return dict(r) if r else None


def public_user(user):
    u = dict(user)
    u.pop("password_hash", None)
    return u


def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return one(get_db().execute("SELECT * FROM users WHERE user_id=?", (uid,)))


def require_user():
    user = current_user()
    if not user:
        abort(401, description="Not signed in")
    return user


def require_admin():
    user = require_user()
    if user["role"] != "Admin":
        abort(403, description="Admin only")
    return user


def log_activity(db, file_id, user_id, action_type, details):
    db.execute(
        "INSERT INTO activity_logs (file_id,user_id,action_type,action_time,details) VALUES (?,?,?,?,?)",
        (file_id, user_id, action_type, now_iso(), details),
    )


@app.errorhandler(400)
@app.errorhandler(401)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(409)
@app.errorhandler(410)
@app.errorhandler(413)
def handle_error(e):
    return jsonify({"error": getattr(e, "description", str(e))}), e.code


# ---------------- static frontend ----------------
@app.route("/")
def index():
    return send_from_directory(APP_DIR, "login.html")


@app.route("/<path:filename>")
def static_files(filename):
    return send_from_directory(APP_DIR, filename)


# ---------------- auth ----------------
@app.get("/api/demo-accounts")
def demo_accounts():
    db = get_db()
    return jsonify(rows(db.execute("SELECT name, email, role FROM users ORDER BY user_id")))


@app.post("/api/auth/login")
def login():
    body = request.get_json(force=True)
    db = get_db()
    user = one(db.execute("SELECT * FROM users WHERE email=?", (body.get("email", "").strip(),)))
    if not user or not check_password_hash(user["password_hash"], body.get("password", "")):
        abort(401, description="Incorrect email or password.")
    session["user_id"] = user["user_id"]
    return jsonify(public_user(user))


@app.post("/api/auth/register")
def register():
    body = request.get_json(force=True)
    db = get_db()
    name, email, password, role = body.get("name", "").strip(), body.get("email", "").strip(), body.get("password"), body.get("role", "Student")
    if not name or not email or not password:
        abort(400, description="Name, email and password are required.")
    if one(db.execute("SELECT 1 FROM users WHERE email=?", (email,))):
        abort(409, description="An account with that email already exists.")
    if role not in ("Student", "Faculty"):
        abort(400, description="Choose Student or Faculty. Admin roles are assigned by an administrator.")
    cur = db.execute(
        "INSERT INTO users (name,email,password_hash,role,storage_quota_bytes,created_at) VALUES (?,?,?,?,?,?)",
        (name, email, generate_password_hash(password), role, 10 * 1024**3, now_iso()),
    )
    db.commit()
    session["user_id"] = cur.lastrowid
    return jsonify(public_user(one(db.execute("SELECT * FROM users WHERE user_id=?", (cur.lastrowid,)))))


@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/session")
def get_session():
    user = current_user()
    if not user:
        abort(401)
    return jsonify(public_user(user))


# ---------------- snapshot ----------------
@app.get("/api/snapshot")
def snapshot():
    user = require_user()
    db = get_db()
    tables = [
        "users", "user_groups", "group_members", "folders", "files", "file_versions",
        "tags", "file_tags", "file_user_permissions", "file_group_permissions",
        "share_links", "activity_logs",
    ]
    data = {t: rows(db.execute(f"SELECT * FROM {t}")) for t in tables}
    for u in data["users"]:
        u.pop("password_hash", None)
    if user["role"] != "Admin":
        visible = set()
        for f in data["files"]:
            try:
                file_access(f["file_id"], allow_deleted=f["owner_id"] == user["user_id"])
                visible.add(f["file_id"])
            except Exception as error:
                from werkzeug.exceptions import HTTPException
                if not isinstance(error, HTTPException):
                    raise
        for table in ("files", "file_versions", "file_tags", "file_user_permissions", "file_group_permissions", "activity_logs"):
            data[table] = [r for r in data[table] if r["file_id"] in visible]
        data["share_links"] = [r for r in data["share_links"] if any(f["file_id"] == r["file_id"] and f["owner_id"] == user["user_id"] for f in data["files"])]
        data["folders"] = [r for r in data["folders"] if r["owner_id"] == user["user_id"]]
    return jsonify(data)


# ---------------- users (admin) ----------------
@app.patch("/api/users/<int:user_id>")
def update_user(user_id):
    require_admin()
    body = request.get_json(force=True)
    db = get_db()
    if "role" in body and body["role"] not in ("Student", "Faculty", "Admin"):
        abort(400, description="Invalid role.")
    if "storage_quota_bytes" in body and (type(body["storage_quota_bytes"]) is not int or body["storage_quota_bytes"] < 0):
        abort(400, description="Quota must be a nonnegative integer.")
    if "role" in body:
        db.execute("UPDATE users SET role=? WHERE user_id=?", (body["role"], user_id))
    if "storage_quota_bytes" in body:
        db.execute("UPDATE users SET storage_quota_bytes=? WHERE user_id=?", (body["storage_quota_bytes"], user_id))
    db.commit()
    return jsonify({"ok": True})


# ---------------- groups ----------------
@app.post("/api/groups")
def create_group():
    user = require_user()
    body = request.get_json(force=True)
    name = body.get("group_name", "").strip()
    if not name:
        abort(400, description="Group name is required.")
    db = get_db()
    if one(db.execute("SELECT 1 FROM user_groups WHERE group_name=?", (name,))):
        abort(409, description="A group with that name already exists.")
    cur = db.execute(
        "INSERT INTO user_groups (group_name,description,created_by,created_at) VALUES (?,?,?,?)",
        (name, body.get("description", ""), user["user_id"], now_iso()),
    )
    db.execute(
        "INSERT INTO group_members (group_id,user_id,joined_at) VALUES (?,?,?)",
        (cur.lastrowid, user["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"group_id": cur.lastrowid})


@app.post("/api/groups/<int:group_id>/members")
def add_member(group_id):
    require_user()
    body = request.get_json(force=True)
    db = get_db()
    db.execute(
        "INSERT OR IGNORE INTO group_members (group_id,user_id,joined_at) VALUES (?,?,?)",
        (group_id, body["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/groups/<int:group_id>/members/<int:user_id>")
def remove_member(group_id, user_id):
    require_user()
    db = get_db()
    db.execute("DELETE FROM group_members WHERE group_id=? AND user_id=?", (group_id, user_id))
    db.commit()
    return jsonify({"ok": True})


# ---------------- folders ----------------
@app.post("/api/folders")
def create_folder():
    user = require_user()
    body = request.get_json(force=True)
    name = body.get("folder_name", "").strip()
    parent_id = body.get("parent_folder_id")
    if not name:
        abort(400, description="Folder name is required.")
    db = get_db()
    owned_folder(parent_id, user["user_id"])
    exists = one(db.execute(
        "SELECT 1 FROM folders WHERE owner_id=? AND parent_folder_id IS ? AND folder_name=?",
        (user["user_id"], parent_id, name),
    ))
    if exists:
        abort(409, description="A folder with that name already exists here.")
    cur = db.execute(
        "INSERT INTO folders (folder_name,parent_folder_id,owner_id,created_at) VALUES (?,?,?,?)",
        (name, parent_id, user["user_id"], now_iso()),
    )
    db.commit()
    return jsonify({"folder_id": cur.lastrowid})


# ---------------- files & versions ----------------
def hash_and_store(file_storage, owner_id):
    data = file_storage.read()
    check_quota(owner_id, len(data))
    checksum = hashlib.sha256(data).hexdigest()
    return checksum, len(data), storage.store(data, checksum, UPLOAD_DIR)


@app.post("/api/files")
def upload_file():
    user = require_user()
    if "file" not in request.files:
        abort(400, description="No file provided.")
    upload = request.files["file"]
    folder_id = request.form.get("folder_id")
    folder_id = int(folder_id) if folder_id else None
    db = get_db()

    existing = one(db.execute(
        "SELECT * FROM files WHERE owner_id=? AND folder_id IS ? AND file_name=? AND is_deleted=0",
        (user["user_id"], folder_id, upload.filename),
    ))
    owned_folder(folder_id, user["user_id"])
    checksum, size, storage_path = hash_and_store(upload, user["user_id"])

    trashed = one(db.execute("SELECT 1 FROM files WHERE owner_id=? AND folder_id IS ? AND file_name=? AND is_deleted=1", (user["user_id"],folder_id,upload.filename)))
    if trashed:
        abort(409, description="A file with this name is in trash. Restore it or rename your upload.")
    if existing:
        file_id = existing["file_id"]
    else:
        cur = db.execute(
            "INSERT INTO files (file_name,folder_id,owner_id,is_deleted,created_at) VALUES (?,?,?,0,?)",
            (upload.filename, folder_id, user["user_id"], now_iso()),
        )
        file_id = cur.lastrowid
        db.execute(
            "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
            (file_id, user["user_id"], "Owner", user["user_id"], now_iso()),
        )

    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    dup = one(db.execute("SELECT 1 FROM file_versions WHERE checksum=? AND file_id!=?", (checksum, file_id)))
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, size, checksum, storage_path, user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Upload" if version_no == 1 else "Modify",
                 f"uploaded version {version_no}" + (" (duplicate content — storage reused)" if dup else ""))
    db.commit()
    return jsonify({"file_id": file_id, "version_no": version_no, "checksum": checksum, "duplicate": bool(dup)})


@app.post("/api/files/<int:file_id>/versions")
def upload_version(file_id):
    user = require_user()
    if "file" not in request.files:
        abort(400, description="No file provided.")
    upload = request.files["file"]
    db = get_db()
    checksum, size, storage_path = hash_and_store(upload, file_access(file_id, "Editor")["owner_id"])
    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    dup = one(db.execute("SELECT 1 FROM file_versions WHERE checksum=? AND file_id!=?", (checksum, file_id)))
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, size, checksum, storage_path, user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Upload" if version_no == 1 else "Modify",
                 f"uploaded version {version_no}" + (" (duplicate content — storage reused)" if dup else ""))
    db.commit()
    return jsonify({"version_no": version_no, "checksum": checksum, "duplicate": bool(dup)})


@app.post("/api/files/<int:file_id>/versions/<int:version_id>/restore")
def restore_version(file_id, version_id):
    user = require_user()
    db = get_db()
    target = one(db.execute("SELECT * FROM file_versions WHERE version_id=? AND file_id=?", (version_id, file_id)))
    if not target:
        abort(404)
    check_quota(file_access(file_id, "Editor")["owner_id"], target["size_bytes"])
    max_no = one(db.execute("SELECT MAX(version_no) v FROM file_versions WHERE file_id=?", (file_id,)))["v"] or 0
    version_no = max_no + 1
    db.execute(
        "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,?,?,?,?,?,?)",
        (file_id, version_no, target["size_bytes"], target["checksum"], target["storage_path"], user["user_id"], now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Restore", f"restored version {target['version_no']} as new version {version_no}")
    db.commit()
    return jsonify({"ok": True})


@app.get("/api/files/<int:file_id>/download")
def download_file(file_id):
    user = require_user()
    db = get_db()
    version = one(db.execute(
        "SELECT * FROM file_versions WHERE file_id=? ORDER BY version_no DESC LIMIT 1", (file_id,)
    ))
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not version or not f:
        abort(404)
    response = storage.download(version, f["file_name"], UPLOAD_DIR)
    if response is None:
        abort(404, description="File content is unavailable for this seeded version.")
    log_activity(db, file_id, user["user_id"], "Download", "downloaded current version")
    db.commit()
    return response


@app.get("/api/files/<int:file_id>/versions/<int:version_id>/download")
def download_version(file_id, version_id):
    user = require_user()
    db = get_db()
    f = file_access(file_id)
    version = one(db.execute("SELECT * FROM file_versions WHERE file_id=? AND version_id=?", (file_id,version_id)))
    if not version:
        abort(404, description="Version not found.")
    response = storage.download(version, f["file_name"], UPLOAD_DIR)
    if response is None:
        abort(404, description="File content is unavailable for this seeded version.")
    log_activity(db, file_id, user["user_id"], "Download", f"downloaded version {version['version_no']}")
    db.commit()
    return response


@app.patch("/api/files/<int:file_id>")
def update_file(file_id):
    user = require_user()
    body = request.get_json(force=True)
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    name = body.get("file_name", f["file_name"])
    folder = body.get("folder_id", f["folder_id"])
    if not isinstance(name, str) or not name.strip():
        abort(400, description="File name is required.")
    if one(db.execute("SELECT 1 FROM files WHERE owner_id=? AND folder_id IS ? AND file_name=? AND file_id!=?", (f["owner_id"],folder,name,file_id))):
        abort(409, description="A file with that name already exists here.")
    if "file_name" in body:
        db.execute("UPDATE files SET file_name=? WHERE file_id=?", (body["file_name"], file_id))
        log_activity(db, file_id, user["user_id"], "Modify", f"renamed \"{f['file_name']}\" to \"{body['file_name']}\"")
    if "folder_id" in body:
        folder_id = body["folder_id"]
        owned_folder(folder_id, f["owner_id"])
        db.execute("UPDATE files SET folder_id=? WHERE file_id=?", (folder_id, file_id))
        dest = "My Files (root)"
        if folder_id:
            folder = one(db.execute("SELECT folder_name FROM folders WHERE folder_id=?", (folder_id,)))
            dest = folder["folder_name"] if folder else dest
        log_activity(db, file_id, user["user_id"], "Modify", f"moved to {dest}")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/copy")
def copy_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    version = one(db.execute("SELECT * FROM file_versions WHERE file_id=? ORDER BY version_no DESC LIMIT 1", (file_id,)))
    check_quota(user["user_id"], version["size_bytes"] if version else 0)
    base, ext = os.path.splitext(f["file_name"])
    new_name = f"{base} (copy){ext}"
    folder_id = f["folder_id"] if f["owner_id"] == user["user_id"] else None
    count = 2
    while one(db.execute("SELECT 1 FROM files WHERE owner_id=? AND folder_id IS ? AND file_name=?", (user["user_id"],folder_id,new_name))):
        new_name = f"{base} (copy {count}){ext}"
        count += 1
    cur = db.execute(
        "INSERT INTO files (file_name,folder_id,owner_id,is_deleted,created_at) VALUES (?,?,?,0,?)",
        (new_name, folder_id, user["user_id"], now_iso()),
    )
    new_id = cur.lastrowid
    db.execute(
        "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?)",
        (new_id, user["user_id"], "Owner", user["user_id"], now_iso()),
    )
    if version:
        db.execute(
            "INSERT INTO file_versions (file_id,version_no,size_bytes,checksum,storage_path,uploaded_by,uploaded_at) VALUES (?,1,?,?,?,?,?)",
            (new_id, version["size_bytes"], version["checksum"], version["storage_path"], user["user_id"], now_iso()),
        )
    for t in rows(db.execute("SELECT tag_id FROM file_tags WHERE file_id=?", (file_id,))):
        db.execute("INSERT INTO file_tags (file_id,tag_id) VALUES (?,?)", (new_id, t["tag_id"]))
    log_activity(db, new_id, user["user_id"], "Upload", f"copied from \"{f['file_name']}\"")
    db.commit()
    return jsonify({"file_id": new_id})


@app.delete("/api/files/<int:file_id>")
def soft_delete_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    db.execute("UPDATE files SET is_deleted=1, deleted_at=? WHERE file_id=?", (now_iso(), file_id))
    log_activity(db, file_id, user["user_id"], "Delete", f"moved \"{f['file_name']}\" to trash")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/restore")
def restore_file(file_id):
    user = require_user()
    db = get_db()
    f = one(db.execute("SELECT * FROM files WHERE file_id=?", (file_id,)))
    if not f:
        abort(404)
    db.execute("UPDATE files SET is_deleted=0, deleted_at=NULL WHERE file_id=?", (file_id,))
    log_activity(db, file_id, user["user_id"], "Restore", f"restored \"{f['file_name']}\" from trash")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permanent")
def permanent_delete_file(file_id):
    require_user()
    db = get_db()
    if not file_access(file_id, "Owner", True)["is_deleted"]:
        abort(409, description="Move the file to trash before deleting permanently.")
    for table in ["file_versions", "file_tags", "file_user_permissions", "file_group_permissions", "share_links", "activity_logs"]:
        db.execute(f"DELETE FROM {table} WHERE file_id=?", (file_id,))
    db.execute("DELETE FROM files WHERE file_id=?", (file_id,))
    db.commit()
    return jsonify({"ok": True})


# ---------------- tags ----------------
@app.post("/api/files/<int:file_id>/tags")
def add_tag(file_id):
    user = require_user()
    body = request.get_json(force=True)
    name = body.get("tag_name", "").strip().lower()
    if not name:
        abort(400, description="Tag name is required.")
    db = get_db()
    tag = one(db.execute("SELECT * FROM tags WHERE tag_name=?", (name,)))
    if not tag:
        cur = db.execute("INSERT INTO tags (tag_name) VALUES (?)", (name,))
        tag_id = cur.lastrowid
    else:
        tag_id = tag["tag_id"]
    db.execute("INSERT OR IGNORE INTO file_tags (file_id,tag_id) VALUES (?,?)", (file_id, tag_id))
    log_activity(db, file_id, user["user_id"], "Modify", f"added tag {name}")
    db.commit()
    return jsonify({"tag_id": tag_id})


@app.delete("/api/files/<int:file_id>/tags/<int:tag_id>")
def remove_tag(file_id, tag_id):
    user = require_user()
    db = get_db()
    db.execute("DELETE FROM file_tags WHERE file_id=? AND tag_id=?", (file_id, tag_id))
    log_activity(db, file_id, user["user_id"], "Modify", "removed a file tag")
    db.commit()
    return jsonify({"ok": True})


# ---------------- permissions ----------------
@app.post("/api/files/<int:file_id>/permissions/user")
def grant_user_permission(file_id):
    user = require_user()
    body = request.get_json(force=True)
    if body.get("permission_type") not in ("Editor", "Viewer"):
        abort(400, description="Sharing permissions must be Editor or Viewer.")
    if body.get("user_id") == file_access(file_id, "Owner")["owner_id"]:
        abort(400, description="The owner permission cannot be changed.")
    db = get_db()
    db.execute(
        "INSERT INTO file_user_permissions (file_id,user_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?) "
        "ON CONFLICT(file_id,user_id) DO UPDATE SET permission_type=excluded.permission_type",
        (file_id, body["user_id"], body["permission_type"], user["user_id"], now_iso()),
    )
    target = one(db.execute("SELECT name FROM users WHERE user_id=?", (body["user_id"],)))
    log_activity(db, file_id, user["user_id"], "Share", f"granted {body['permission_type']} to {target['name']}")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permissions/user/<int:user_id>")
def revoke_user_permission(file_id, user_id):
    actor = require_user()
    if user_id == file_access(file_id, "Owner")["owner_id"]:
        abort(400, description="The owner permission cannot be removed.")
    db = get_db()
    db.execute("DELETE FROM file_user_permissions WHERE file_id=? AND user_id=?", (file_id, user_id))
    target = one(db.execute("SELECT name FROM users WHERE user_id=?", (user_id,)))
    log_activity(db, file_id, actor["user_id"], "Modify", f"removed access for {target['name'] if target else 'user'}")
    db.commit()
    return jsonify({"ok": True})


@app.post("/api/files/<int:file_id>/permissions/group")
def grant_group_permission(file_id):
    user = require_user()
    body = request.get_json(force=True)
    if body.get("permission_type") not in ("Editor", "Viewer"):
        abort(400, description="Sharing permissions must be Editor or Viewer.")
    db = get_db()
    db.execute(
        "INSERT INTO file_group_permissions (file_id,group_id,permission_type,granted_by,granted_at) VALUES (?,?,?,?,?) "
        "ON CONFLICT(file_id,group_id) DO UPDATE SET permission_type=excluded.permission_type",
        (file_id, body["group_id"], body["permission_type"], user["user_id"], now_iso()),
    )
    target = one(db.execute("SELECT group_name FROM user_groups WHERE group_id=?", (body["group_id"],)))
    log_activity(db, file_id, user["user_id"], "Share", f"shared with group {target['group_name']} ({body['permission_type']})")
    db.commit()
    return jsonify({"ok": True})


@app.delete("/api/files/<int:file_id>/permissions/group/<int:group_id>")
def revoke_group_permission(file_id, group_id):
    actor = require_user()
    db = get_db()
    db.execute("DELETE FROM file_group_permissions WHERE file_id=? AND group_id=?", (file_id, group_id))
    target = one(db.execute("SELECT group_name FROM user_groups WHERE group_id=?", (group_id,)))
    log_activity(db, file_id, actor["user_id"], "Modify", f"removed group access for {target['group_name'] if target else 'group'}")
    db.commit()
    return jsonify({"ok": True})


# ---------------- share links ----------------
@app.post("/api/files/<int:file_id>/share-links")
def create_share_link(file_id):
    user = require_user()
    body = request.get_json(force=True) or {}
    db = get_db()
    maximum = body.get("max_downloads")
    if maximum is not None and (type(maximum) is not int or maximum < 1):
        abort(400, description="Download limit must be a positive integer.")
    if body.get("expiry_date"):
        try:
            datetime.fromisoformat(body["expiry_date"].replace("Z", "+00:00"))
        except (ValueError, TypeError):
            abort(400, description="Invalid expiry date.")
    token = secrets.token_urlsafe(32)
    db.execute(
        "INSERT INTO share_links (file_id,token,created_by,expiry_date,max_downloads,download_count,created_at) VALUES (?,?,?,?,?,0,?)",
        (file_id, token, user["user_id"], body.get("expiry_date"), body.get("max_downloads"), now_iso()),
    )
    log_activity(db, file_id, user["user_id"], "Share", "created a public share link")
    db.commit()
    return jsonify({"token": token})


@app.delete("/api/share-links/<int:link_id>")
def revoke_share_link(link_id):
    user = require_user()
    db = get_db()
    link = one(db.execute("SELECT * FROM share_links WHERE link_id=?", (link_id,)))
    if not link:
        abort(404)
    file_access(link["file_id"], "Owner", True)
    db.execute("DELETE FROM share_links WHERE link_id=?", (link_id,))
    if link:
        log_activity(db, link["file_id"], user["user_id"], "Modify", "revoked a share link")
    db.commit()
    return jsonify({"ok": True})


@app.get("/s/<token>")
def public_download(token):
    db = get_db()
    db.execute("BEGIN IMMEDIATE")
    link = one(db.execute("SELECT * FROM share_links WHERE token=?", (token,)))
    if not link:
        abort(404, description="Share link not found.")
    if link["expiry_date"] and datetime.fromisoformat(link["expiry_date"].replace("Z", "+00:00")).replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
        abort(410, description="This link has expired.")
    if link["max_downloads"] is not None and link["download_count"] >= link["max_downloads"]:
        abort(410, description="This link has reached its download limit.")
    f = one(db.execute("SELECT * FROM files WHERE file_id=? AND is_deleted=0", (link["file_id"],)))
    version = one(db.execute("SELECT * FROM file_versions WHERE file_id=? ORDER BY version_no DESC LIMIT 1", (link["file_id"],)))
    if not f or not version:
        abort(404, description="File content is unavailable.")
    response = storage.download(version, f["file_name"], UPLOAD_DIR)
    if response is None:
        abort(404, description="File content is unavailable.")
    db.execute("UPDATE share_links SET download_count=download_count+1 WHERE link_id=?", (link["link_id"],))
    log_activity(db, f["file_id"], link["created_by"], "Download", "downloaded through a public share link")
    db.commit()
    return response


if __name__ == "__main__":
    if os.environ.get("DATABASE_BACKEND", "sqlite") == "sqlite" and not os.path.exists(DB_PATH):
        import seed
        seed.seed()
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    app.run(host="127.0.0.1", port=5050, debug=os.environ.get("FLASK_DEBUG") == "1")
