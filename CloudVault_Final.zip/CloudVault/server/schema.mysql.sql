-- MySQL design from resources/CloudVault_DB_Design.docx.
-- Surrogate primary keys use AUTO_INCREMENT for API-generated IDs.
CREATE TABLE users (
user_id INT AUTO_INCREMENT,
name VARCHAR(100) NOT NULL,
email VARCHAR(150) NOT NULL,
password_hash VARCHAR(255) NOT NULL,
role ENUM('Student','Faculty','Admin') NOT NULL DEFAULT 'Student',
storage_quota_bytes BIGINT NOT NULL DEFAULT 10737418240,
storage_used_bytes BIGINT NOT NULL DEFAULT 0,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (user_id),
UNIQUE KEY uq_users_1 (email)
);
CREATE TABLE user_groups (
group_id INT AUTO_INCREMENT,
group_name VARCHAR(100) NOT NULL,
description VARCHAR(255),
created_by INT NOT NULL,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (group_id),
UNIQUE KEY uq_user_groups_1 (group_name),
FOREIGN KEY (created_by) REFERENCES users(user_id)
);
CREATE TABLE group_members (
group_id INT,
user_id INT,
joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (group_id, user_id),
FOREIGN KEY (group_id) REFERENCES user_groups(group_id),
FOREIGN KEY (user_id) REFERENCES users(user_id)
);
CREATE TABLE folders (
folder_id INT AUTO_INCREMENT,
folder_name VARCHAR(150) NOT NULL,
parent_folder_id INT,
owner_id INT NOT NULL,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (folder_id),
UNIQUE KEY uq_folders_1 (owner_id, parent_folder_id, folder_name),
FOREIGN KEY (parent_folder_id) REFERENCES folders(folder_id),
FOREIGN KEY (owner_id) REFERENCES users(user_id)
);
CREATE TABLE files (
file_id INT AUTO_INCREMENT,
file_name VARCHAR(255) NOT NULL,
folder_id INT,
owner_id INT NOT NULL,
is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
deleted_at DATETIME,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (file_id),
UNIQUE KEY uq_files_1 (owner_id, folder_id, file_name),
FOREIGN KEY (folder_id) REFERENCES folders(folder_id),
FOREIGN KEY (owner_id) REFERENCES users(user_id)
);
CREATE TABLE file_versions (
version_id INT AUTO_INCREMENT,
file_id INT NOT NULL,
version_no INT NOT NULL,
size_bytes BIGINT NOT NULL,
checksum CHAR(64) NOT NULL,
storage_path VARCHAR(500) NOT NULL,
uploaded_by INT NOT NULL,
uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (version_id),
UNIQUE KEY uq_file_versions_1 (file_id, version_no),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (uploaded_by) REFERENCES users(user_id)
);
CREATE TABLE tags (
tag_id INT AUTO_INCREMENT,
tag_name VARCHAR(50) NOT NULL,
PRIMARY KEY (tag_id),
UNIQUE KEY uq_tags_1 (tag_name)
);
CREATE TABLE file_tags (
file_id INT,
tag_id INT,
PRIMARY KEY (file_id, tag_id),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (tag_id) REFERENCES tags(tag_id)
);
CREATE TABLE file_user_permissions (
file_id INT,
user_id INT,
permission_type ENUM('Owner','Editor','Viewer') NOT NULL,
granted_by INT NOT NULL,
granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (file_id, user_id),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (user_id) REFERENCES users(user_id),
FOREIGN KEY (granted_by) REFERENCES users(user_id)
);
CREATE TABLE file_group_permissions (
file_id INT,
group_id INT,
permission_type ENUM('Editor','Viewer') NOT NULL,
granted_by INT NOT NULL,
granted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (file_id, group_id),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (group_id) REFERENCES user_groups(group_id),
FOREIGN KEY (granted_by) REFERENCES users(user_id)
);
CREATE TABLE share_links (
link_id INT AUTO_INCREMENT,
file_id INT NOT NULL,
token VARCHAR(64) NOT NULL,
created_by INT NOT NULL,
expiry_date DATETIME,
max_downloads INT,
download_count INT NOT NULL DEFAULT 0,
created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (link_id),
UNIQUE KEY uq_share_links_1 (token),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (created_by) REFERENCES users(user_id)
);
CREATE TABLE activity_logs (
log_id INT AUTO_INCREMENT,
file_id INT NOT NULL,
user_id INT NOT NULL,
action_type ENUM('Upload','Share','Modify','Delete','Restore','Download') NOT NULL,
action_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
details VARCHAR(255),
PRIMARY KEY (log_id),
FOREIGN KEY (file_id) REFERENCES files(file_id),
FOREIGN KEY (user_id) REFERENCES users(user_id)
);
