import io
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app as server


class DatabaseRules(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        server.DB_PATH = str(Path(self.temp.name) / 'test.db')
        server.UPLOAD_DIR = self.temp.name
        db = sqlite3.connect(server.DB_PATH)
        db.executescript(Path(server.BASE_DIR, 'schema.sql').read_text())
        db.close()
        server.app.config['TESTING'] = True
        self.owner = server.app.test_client()
        self.viewer = server.app.test_client()
        self.editor = server.app.test_client()
        for client, name in [(self.owner,'owner'), (self.viewer,'viewer'), (self.editor,'editor')]:
            self.assertEqual(client.post('/api/auth/register', json=dict(name=name,email=name+'@test.edu',password='secret')).status_code,200)

    def tearDown(self):
        self.temp.cleanup()

    def upload(self, client=None, name='notes.txt', content=b'hello'):
        return (client or self.owner).post('/api/files',data={'file':(io.BytesIO(content),name)})

    def test_permissions_snapshot_and_owner(self):
        fid=self.upload().json['file_id']
        self.assertEqual(self.viewer.get('/api/snapshot').json['files'],[])
        self.assertEqual(self.viewer.patch(f'/api/files/{fid}',json={'file_name':'other'}).status_code,403)
        self.assertEqual(self.owner.post(f'/api/files/{fid}/permissions/user',json={'user_id':2,'permission_type':'Viewer'}).status_code,200)
        self.assertEqual(len(self.viewer.get('/api/snapshot').json['files']),1)
        self.assertEqual(self.viewer.post(f'/api/files/{fid}/versions',data={'file':(io.BytesIO(b'x'),'x')}).status_code,403)
        self.owner.post(f'/api/files/{fid}/permissions/user',json={'user_id':3,'permission_type':'Editor'})
        self.assertEqual(self.editor.post(f'/api/files/{fid}/versions',data={'file':(io.BytesIO(b'x'),'x')}).json['version_no'],2)
        self.assertEqual(self.editor.delete(f'/api/files/{fid}').status_code,403)
        self.assertEqual(self.owner.delete(f'/api/files/{fid}/permissions/user/1').status_code,400)

    def test_versions_quota_and_trash(self):
        fid=self.upload().json['file_id']
        self.assertEqual(self.upload().json['version_no'],2)
        self.assertEqual(self.owner.get('/api/snapshot').json['users'][0]['storage_used_bytes'],10)
        self.owner.delete(f'/api/files/{fid}')
        self.assertEqual(self.owner.get('/api/snapshot').json['users'][0]['storage_used_bytes'],10)
        self.assertEqual(self.owner.get(f'/api/files/{fid}/download').status_code,409)
        self.owner.post(f'/api/files/{fid}/restore')
        db=sqlite3.connect(server.DB_PATH);db.execute('UPDATE users SET storage_quota_bytes=10 WHERE user_id=1');db.commit();db.close()
        self.assertEqual(self.upload(name='new.txt').status_code,409)
        self.assertEqual(self.owner.delete(f'/api/files/{fid}/permanent').status_code,409)
        self.owner.delete(f'/api/files/{fid}')
        self.assertEqual(self.owner.delete(f'/api/files/{fid}/permanent').status_code,200)
        self.assertEqual(self.owner.get('/api/snapshot').json['users'][0]['storage_used_bytes'],0)

    def test_links(self):
        fid=self.upload().json['file_id']
        token=self.owner.post(f'/api/files/{fid}/share-links',json={'max_downloads':1}).json['token']
        public=server.app.test_client()
        response = public.get('/s/'+token)
        self.assertEqual(response.data,b'hello')
        response.close()
        self.assertEqual(public.get('/s/'+token).status_code,410)
        token=self.owner.post(f'/api/files/{fid}/share-links',json={'expiry_date':'2000-01-01T00:00:00Z'}).json['token']
        self.assertEqual(public.get('/s/'+token).status_code,410)
        self.assertEqual(self.owner.post(f'/api/files/{fid}/share-links',json={'max_downloads':-1}).status_code,400)

    def test_folder_ownership_and_copy(self):
        folder=self.viewer.post('/api/folders',json={'folder_name':'Private'}).json['folder_id']
        self.assertEqual(self.owner.post('/api/folders',json={'folder_name':'Nested','parent_folder_id':folder}).status_code,400)
        fid=self.upload().json['file_id']
        self.assertEqual(self.owner.patch(f'/api/files/{fid}',json={'folder_id':folder}).status_code,400)
        for _ in range(2):
            self.assertEqual(self.owner.post(f'/api/files/{fid}/copy').status_code,200)
        self.assertEqual(self.owner.post('/api/auth/register',json={'name':'a','email':'admin@test','password':'x','role':'Admin'}).status_code,400)

    def test_group_sharing_tags_restore_and_dedup(self):
        fid = self.upload().json['file_id']
        group = self.owner.post('/api/groups', json={'group_name':'Project','description':'Team'}).json['group_id']
        self.assertEqual(self.viewer.post(f'/api/groups/{group}/members', json={'user_id':2}).status_code,403)
        self.owner.post(f'/api/groups/{group}/members', json={'user_id':2})
        self.owner.post(f'/api/files/{fid}/permissions/group',json={'group_id':group,'permission_type':'Editor'})
        self.assertEqual(self.viewer.patch(f'/api/files/{fid}',json={'file_name':'renamed.txt'}).status_code,200)
        tag=self.viewer.post(f'/api/files/{fid}/tags',json={'tag_name':'research'}).json['tag_id']
        self.assertEqual(len(self.viewer.get('/api/snapshot').json['file_tags']),1)
        self.viewer.delete(f'/api/files/{fid}/tags/{tag}')
        original=self.owner.get('/api/snapshot').json['file_versions'][0]['version_id']
        self.viewer.post(f'/api/files/{fid}/versions',data={'file':(io.BytesIO(b'new'),'notes.txt')})
        self.assertEqual(self.viewer.post(f'/api/files/{fid}/versions/{original}/restore').status_code,200)
        snapshot=self.owner.get('/api/snapshot').json
        versions=snapshot['file_versions']
        self.assertEqual([v['version_no'] for v in versions],[1,2,3])
        self.assertEqual(versions[0]['checksum'],versions[2]['checksum'])
        response=self.viewer.get(f'/api/files/{fid}/versions/{original}/download')
        self.assertEqual(response.data,b'hello');response.close()
        self.owner.delete(f'/api/files/{fid}/permissions/group/{group}')
        self.assertEqual(self.viewer.get('/api/snapshot').json['files'],[])
        self.assertEqual(self.upload(name='duplicate.txt').json['duplicate'],True)
        self.assertEqual(set(a['action_type'] for a in self.owner.get('/api/snapshot').json['activity_logs']), {'Upload','Share','Modify','Restore','Download'})

    def test_admin_and_password_migration(self):
        self.assertEqual(self.owner.patch('/api/users/2',json={'role':'Admin'}).status_code,403)
        db=sqlite3.connect(server.DB_PATH)
        db.execute("UPDATE users SET role='Admin' WHERE user_id=1")
        db.commit();db.close()
        self.assertEqual(self.owner.patch('/api/users/2',json={'storage_quota_bytes':123}).status_code,200)
        self.assertEqual(self.owner.patch('/api/users/2',json={'role':'invalid'}).status_code,400)
        self.assertNotIn('password_hash',self.owner.get('/api/snapshot').json['users'][0])
        db=sqlite3.connect(server.DB_PATH)
        db.execute('ALTER TABLE users RENAME COLUMN password_hash TO password')
        db.execute("UPDATE users SET password='legacy'")
        db.commit();db.close()
        self.assertEqual(server.app.test_client().post('/api/auth/login',json={'email':'owner@test.edu','password':'legacy'}).status_code,200)
        db=sqlite3.connect(server.DB_PATH)
        self.assertNotEqual(db.execute('SELECT password_hash FROM users LIMIT 1').fetchone()[0],'legacy')
        db.close()

if __name__=='__main__': unittest.main()
