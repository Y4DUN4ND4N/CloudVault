"""Run only against the disposable MySQL test container on port 33079."""
import os,sys,time,tempfile,io
os.environ.update(DATABASE_BACKEND='mysql',MYSQL_HOST='127.0.0.1',MYSQL_PORT='33079',MYSQL_USER='root',MYSQL_PASSWORD='cloudvault-test-only',MYSQL_DATABASE='cloudvault')
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pymysql
for attempt in range(30):
    try:
        db=pymysql.connect(host='127.0.0.1',port=33079,user='root',password='cloudvault-test-only',database='cloudvault')
        break
    except pymysql.OperationalError:
        time.sleep(1)
else: raise RuntimeError('MySQL did not become ready')
server_root = Path(__file__).resolve().parents[1]
with db.cursor() as cursor:
    for sql in Path(server_root, 'schema.mysql.sql').read_text().split(';'):
        if sql.strip():cursor.execute(sql)
db.commit();db.close()
import app as server
server.app.config['TESTING']=True
with tempfile.TemporaryDirectory() as directory:
    server.UPLOAD_DIR=directory
    owner=server.app.test_client();other=server.app.test_client();public=server.app.test_client()
    for client,name in [(owner,'owner'),(other,'other')]:
        r=client.post('/api/auth/register',json={'name':name,'email':name+'@test','password':'secret'})
        assert r.status_code==200,(r.status_code,r.data)
    def post(path,client=owner,**args):
        r=client.post(path,**args);assert r.status_code==200,(path,r.status_code,r.data);return r.json
    folder=post('/api/folders',json={'folder_name':'Project'})['folder_id']
    nested=post('/api/folders',json={'folder_name':'Notes','parent_folder_id':folder})['folder_id']
    fid=post('/api/files',data={'file':(io.BytesIO(b'first'),'notes.txt'),'folder_id':str(nested)})['file_id']
    assert other.get('/api/snapshot').json['files']==[]
    post(f'/api/files/{fid}/permissions/user',json={'user_id':2,'permission_type':'Viewer'})
    assert other.patch(f'/api/files/{fid}',json={'file_name':'denied'}).status_code==403
    post(f'/api/files/{fid}/permissions/user',json={'user_id':2,'permission_type':'Editor'})
    assert post(f'/api/files/{fid}/versions',client=other,data={'file':(io.BytesIO(b'second'),'notes.txt')})['version_no']==2
    original=owner.get('/api/snapshot').json['file_versions'][0]['version_id']
    post(f'/api/files/{fid}/versions/{original}/restore',client=other)
    post(f'/api/files/{fid}/tags',client=other,json={'tag_name':'research'})
    group=post('/api/groups',json={'group_name':'Team'})['group_id']
    post(f'/api/groups/{group}/members',json={'user_id':2})
    post(f'/api/files/{fid}/permissions/group',json={'group_id':group,'permission_type':'Editor'})
    post(f'/api/files/{fid}/permissions/group',json={'group_id':group,'permission_type':'Viewer'})
    token=post(f'/api/files/{fid}/share-links',json={'max_downloads':1})['token']
    r=public.get('/s/'+token);assert r.data==b'first';r.close()
    assert public.get('/s/'+token).status_code==410
    token=post(f'/api/files/{fid}/share-links',json={'expiry_date':'2000-01-01T00:00:00Z'})['token']
    assert public.get('/s/'+token).status_code==410
    duplicate=post('/api/files',data={'file':(io.BytesIO(b'first'),'copy.txt')});assert duplicate['duplicate']
    assert owner.get('/api/snapshot').json['users'][0]['storage_used_bytes']==21
    assert owner.delete(f'/api/files/{fid}').status_code==200
    post(f'/api/files/{fid}/restore')
    assert owner.delete(f'/api/files/{fid}').status_code==200
    assert owner.delete(f'/api/files/{fid}/permanent').status_code==200
    assert owner.get('/api/snapshot').json['users'][0]['storage_used_bytes']==5
print('MySQL 8.4 schema and full API integration checks passed')
