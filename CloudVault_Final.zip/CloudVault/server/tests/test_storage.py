import os
import unittest
from unittest.mock import patch
import boto3
from botocore.stub import Stubber
from flask import Flask
import storage


class ObjectStorage(unittest.TestCase):
    def test_s3_upload_and_reuse(self):
        client=boto3.client('s3',region_name='us-east-1',aws_access_key_id='test',aws_secret_access_key='test')
        with Stubber(client) as stub, patch.dict(os.environ,{'STORAGE_BACKEND':'s3','S3_BUCKET':'test-bucket'}), patch.object(storage,'s3_client',return_value=client):
            params={'Bucket':'test-bucket','Key':'checksum'}
            stub.add_client_error('head_object',service_error_code='404',http_status_code=404,expected_params=params)
            stub.add_response('put_object',{},dict(params,Body=b'content'))
            stub.add_response('head_object',{},params)
            self.assertEqual(storage.store(b'content','checksum','/tmp'),'s3://test-bucket/checksum')
            self.assertEqual(storage.store(b'content','checksum','/tmp'),'s3://test-bucket/checksum')
            stub.assert_no_pending_responses()
