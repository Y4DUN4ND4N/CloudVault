"""Content-addressed local or S3 object storage; metadata stays in the database."""
import io
import os
from flask import send_file


def s3_client():
    import boto3
    return boto3.client('s3', endpoint_url=os.environ.get('S3_ENDPOINT_URL'))


def store(data, checksum, directory):
    if os.environ.get('STORAGE_BACKEND', 'local') == 's3':
        client = s3_client()
        bucket = os.environ['S3_BUCKET']
        from botocore.exceptions import ClientError
        try:
            client.head_object(Bucket=bucket, Key=checksum)
        except ClientError as error:
            if error.response['Error']['Code'] not in ('404', 'NoSuchKey', 'NotFound'):
                raise
            client.put_object(Bucket=bucket, Key=checksum, Body=data)
        return f's3://{bucket}/{checksum}'
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, checksum)
    if not os.path.exists(path):
        with open(path, 'wb') as output:
            output.write(data)
    return f'uploads/{checksum}'


def download(version, filename, directory):
    if version['storage_path'].startswith('s3://'):
        bucket, key = version['storage_path'][5:].split('/', 1)
        from botocore.exceptions import ClientError
        try:
            obj = s3_client().get_object(Bucket=bucket, Key=key)
        except ClientError as error:
            if error.response['Error']['Code'] in ('404', 'NoSuchKey', 'NotFound'):
                return None
            raise
        stream = obj['Body']
        try:
            data = stream.read()
        finally:
            stream.close()
        return send_file(io.BytesIO(data), as_attachment=True, download_name=filename)
    path = os.path.join(directory, version['checksum'])
    return send_file(path, as_attachment=True, download_name=filename) if os.path.isfile(path) else None
