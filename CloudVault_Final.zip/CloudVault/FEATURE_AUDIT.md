# CloudVault design and feature audit

The implementation follows the twelve-relation schema in `resources/CloudVault_DB_Design.docx`. The PDF named `03. DB Design.pdf` is the assignment template, while the project abstract describes the proposed features and MySQL/object-storage architecture. The ZIP contains an earlier copy of the project.

## Database correspondence

`server/schema.mysql.sql` contains the document's MySQL DDL with the same twelve tables, columns, primary keys, foreign keys, alternate unique keys and enums. Surrogate IDs additionally use AUTO_INCREMENT so the application can create records. `server/schema.sql` is the SQLite demo equivalent; it now includes `password_hash` and `storage_used_bytes`. Existing local passwords are migrated to hashes without resetting files or accounts.

The document's narrative mentions Owner for group sharing, but its actual DDL limits groups to Editor/Viewer. The implementation follows the DDL. Each file has one owning user; that owner manages sharing and deletion. Editors can upload and restore versions, rename files and modify tags. Viewers can download and make their own copies. Admins can inspect aggregate usage and manage account quotas and roles.

## Feature coverage

| Requirement | Implementation and user flow |
| --- | --- |
| Student, Faculty and Admin accounts; unique email | Sign in and registration; account roles in Admin. Passwords are hashed. Admin assignment requires an existing administrator. |
| File upload and download | Library upload modal, file download, bulk download. Metadata and content stored separately. |
| Hierarchical folders and root files | New folder, nested folder navigation, breadcrumbs, move destination. Folder ownership checked on the server. |
| Sequential version history | Re-upload preserves earlier versions and assigns the next version number. |
| View and restore older versions | Detail panel Versions tab downloads any version or restores it as a new current version. |
| Checksum duplicate detection and storage reuse | SHA-256 content-addressed uploads; identical content reuses its object. Reports show matching versions and saved bytes. |
| Tags and file search | Detail tags, bulk tagging, search by filename, tag or owner. |
| Individual sharing | Detail Access tab grants and revokes Editor/Viewer permissions. |
| Groups and membership | Reports creates groups and manages members; only creator/Admin may change membership. |
| Group sharing | Detail Access tab grants/revokes group permissions; group sidebar lists accessible files. |
| Owner, Editor and Viewer enforcement | Every file API checks direct and inherited group access. Snapshots exclude inaccessible file metadata. Owner grant cannot be removed or demoted. |
| Share links | Detail Share links creates a real URL on the current origin and revokes links. Tokens are random. |
| Expiry and maximum download count | Public `/s/<token>` checks expiry and atomically reserves each successful download against its limit. Unavailable/deleted content cannot be downloaded. |
| Soft delete and recovery | Deleted library view restores files. Permanent deletion requires trash first and confirmation in the UI. |
| Activity history | Upload, Share, Modify, Delete, Restore and Download events identify user/file/time. Tag edits and version downloads are logged. |
| Storage usage and quota | Admin/report usage and library quota meter; server prevents uploads, copies and restores exceeding quota. Retained versions and trash count toward logical usage. Dedup savings are reported separately. |
| MySQL database | `DATABASE_BACKEND=mysql` connects through the MySQL adapter to the documented schema. SQLite remains the local preview default. |
| Separate object storage | `STORAGE_BACKEND=s3` stores and retrieves checksum-addressed S3 objects. Local preview uses the uploads directory. |

## Verification and limits

A temporary MySQL 8.4 instance successfully applied the documented schema and passed end-to-end API checks for accounts, nested folders, uploads, private snapshots, direct/group permissions, version upload/restore, tags, duplicate reuse, expiry/download limits, trash and permanent deletion. S3 operations were checked with AWS SDK stub responses; a live S3 account was not configured.

Run `server/venv/bin/python -m unittest discover -s server/tests -v`. Tests use disposable databases and content, never reset the working database. They cover private snapshots, Viewer/Editor restrictions, owner protection, group sharing and revocation, tags, sequential versions and restoration, duplicate detection, quotas, trash, link expiry and limits, admin validation, password migration and S3 object reuse.

Seeded historical versions have metadata but many have no binary content; downloading one reports that its content is unavailable. Newly uploaded files have actual content. Storage usage is a maintained derived total of all owned version sizes; physical savings are a separate measure. Object garbage collection is not automatic, so unreferenced content can remain after permanent deletion.

Use the configuration in `README.md` for MySQL/S3 deployment. The local preview should not be described as a running MySQL or S3 deployment.
