# CloudVault design system

A practical academic file workspace. Warm paper, forest green controls, readable tables and quiet borders. Avoid decorative grids, promotional cards, gradients and oversized status badges. Use IBM Plex Sans for headings and body, JetBrains Mono for checksums and byte counts. All colours and fonts come from app/css/tokens.css.

The file library has a clear page heading, folder breadcrumb, search and a dense table. Sidebar navigation stays secondary to content. Reports use an open statistics strip and bordered tables; panels do not need shadows. Sign-in pairs a short explanation of the actual product with a compact form. Light and dark modes share the same hierarchy.

Preserve mobile drawers and navigation menus. Wide tables scroll within their containers. Use the existing icon set, visible keyboard focus, and reduced-motion support. Primary actions use the green accent; destructive actions use the danger tokens. Keep existing spacing, radius and motion tokens.
