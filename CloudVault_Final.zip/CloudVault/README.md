# CloudVault

CloudVault is an academic file storage and management application for students, faculty and project teams. It combines a file library with folder organisation, version history, tags, individual and group sharing, public download links, recoverable deletion, storage quotas and activity records.

The frontend uses HTML, CSS and JavaScript. A Flask API enforces business rules and stores metadata in a relational database. File content is stored separately using checksum-addressed local files or S3-compatible objects. The project includes the twelve-table MySQL schema specified in the supplied database-design document, as well as a SQLite equivalent for a simple local demonstration.

## 1. What is included

The final package starts with exactly two accounts and no files, folders or groups:

| Account | Email | Password | Role | Quota |
| --- | --- | --- | --- | --- |
| Test | test@college.edu | demo | Student | 10 GiB |
| Admin | admin@college.edu | demo | Admin | 50 GiB |

These are demonstration credentials. Passwords in the database are hashed. New accounts can be registered from the sign-in page. Creating more accounts is useful when demonstrating group collaboration.

The included database uses SQLite and local file storage. MySQL and S3 are optional deployment configurations; enabling them requires the corresponding services and credentials.

## 2. Installation and local startup

### Requirements

- Python 3.10 or newer with pip and virtual-environment support.
- A modern browser.
- Internet access when installing Python dependencies. Google Fonts are optional for appearance; the interface also has fallback fonts.
- Node.js only if you want to run the JavaScript syntax checks.
- MySQL and an S3-compatible service only when selecting those backends.

### Linux and macOS

Extract the ZIP, open a terminal in its `CloudVault` directory, and run:

```sh
python3 -m venv server/venv
server/venv/bin/python -m pip install -r server/requirements.txt
server/venv/bin/python server/app.py
```

### Windows PowerShell

```powershell
py -m venv server/venv
server\venv\Scripts\python.exe -m pip install -r server\requirements.txt
server\venv\Scripts\python.exe server\app.py
```

Open **http://127.0.0.1:5050** and sign in with either demo account. Keep the terminal running while using the application. Stop it with Ctrl+C.

Serve the frontend through Flask. Opening the HTML files directly will not provide a working API connection. No frontend build step or npm install is needed.

The package does not include a virtual environment or session signing key. Dependencies are installed on your machine, and a local signing key is generated on startup. Startup preserves the included database. If the SQLite database is missing, startup creates the two-account demonstration database.

## 3. Accounts and authentication

Users sign in using an email address and password. Registration requires a name, unique email, password and Student or Faculty role. Admin access cannot be selected during registration; an existing administrator assigns that role.

Passwords are hashed using Werkzeug's password helpers. Flask sessions identify the signed-in user, and protected API routes require a valid session. An older local database containing plaintext passwords is migrated to the `password_hash` field on access.

Sign out using the top-right navigation. The sign-in page also provides clickable demo accounts that fill in their demonstration credentials.

## 4. File library and navigation

The library provides these views:

| View | Purpose |
| --- | --- |
| My Files | Files owned by you in the current folder; folders provide deeper navigation. |
| Shared with me | Files another owner has shared with you directly or through a group. |
| Shared by me | Your files with individual permissions, group permissions or public links. |
| Tagged | Accessible files that have at least one tag. |
| Deleted | Your soft-deleted files, available for recovery or permanent deletion. |
| Group navigation | Accessible files shared with a group you belong to. |

A file row displays its name, owner, modification time, current size, sharing information and tags. Clicking a file opens its detail panel. Its tabs cover Versions, Access, Share links and Activity. The interface includes light/dark themes, responsive navigation and mobile detail drawers.

## 5. Uploads and downloads

Click **Upload files**, then choose one or more files or drag them into the upload area. In My Files, uploads go into the folder currently open. An upload made from another library view goes into your root library.

The server computes a SHA-256 checksum, stores content separately, creates file/version metadata, grants the owner permission and records an Upload event. The upload list displays success, duplicate-storage reuse or an error.

Click a file and choose **Download**, or use its row menu. Downloads require access to the file and are recorded in the activity log. Requests have a 100 MiB upload limit, and user quotas can impose a lower effective limit.

## 6. Folders and file organisation

Use the folder button beside Upload files to create a folder. Open an existing folder and create another folder to build a hierarchy. Breadcrumbs let you return to parent folders or the root.

The file menu supports:

- **Rename:** changes the file's name without replacing its version content.
- **Move to:** places the file in an existing folder or the owner's root.
- **Make a copy:** creates a separate owned file with its own version-one record and copied tags. Identical content reuses storage. Repeated copies receive distinct names.
- **Delete:** moves an owned file into Deleted.

A copied shared file belongs to the person making the copy and goes into that person's root library. Its source permissions and public links are not copied. Folder destinations must belong to the file owner. Conflicting file/folder names are rejected where the application checks them.

The current interface creates and navigates folders; it does not offer folder rename, move or deletion controls.

## 7. Version history and restoration

Every file has at least one version. The initial upload creates version 1. Subsequent uploads create sequential versions without overwriting earlier records.

To upload a new version:

1. Click the existing file.
2. Open **Versions**.
3. Click **Upload new version** and select the updated content.

Uploading the same filename into the same folder of your own library also adds a version to the existing active file. A matching name in Deleted produces a conflict so that a trashed file is not silently replaced.

Each version records its number, size, checksum, storage path, uploader and upload timestamp. **Download version** retrieves a particular historical snapshot. **Restore this version** creates a new current version using earlier content.

For example, restoring version 1 while version 3 is current produces version 4 with version 1's content. Versions 1, 2 and 3 remain in the history. Owners and Editors can upload and restore versions; Viewers can download them. These are complete file snapshots, without branching, merging or line-by-line diffs.

## 8. Duplicate detection and storage reuse

SHA-256 hashes identify byte-for-byte identical content. The storage key is based on that checksum rather than the filename. Different filenames or repeated versions can reference the same stored content while retaining separate metadata records.

Upload feedback and version details identify matching content. Reports show groups of matching checksums and avoided duplicate storage. Duplicate savings are distinct from the user's logical quota: version records still count toward quota even when they share an object.

## 9. Tags, search and sorting

In a file's detail panel, enter a tag and press Enter. Use the tag's remove control to detach it. Tags are normalised to lowercase and can be reused across files. Owners and Editors can change tags; Viewers cannot.

Search matches filename, owner name or tag within the current library view and folder scope. The Tagged view collects accessible tagged files. Name, modification time and size sorting are supported. The sort button cycles among those criteria.

## 10. Individual sharing and access levels

Only the file owner can manage sharing. To share with an account:

1. Click the file and open **Access**.
2. Select the person under **People** in the recipient dropdown.
3. Choose Editor or Viewer.
4. Click **Grant**.

Existing grants can be changed or removed using their permission control. The owner grant cannot be removed or demoted.

| Access | Allowed actions |
| --- | --- |
| Owner | Download and copy; upload/restore versions; rename/move; change tags; manage sharing and links; delete, recover and permanently delete. |
| Editor | Download and copy; upload/restore versions; rename; change tags. Server-authorised moves must target the owner's folders. Sharing and deletion remain owner actions. |
| Viewer | Download current/historical content and create an independently owned copy. Cannot modify the source. |

The API checks permissions for file operations, including requests made outside the interface. For ordinary users, snapshots omit inaccessible file metadata. Direct grants and group membership both contribute to effective access; an Editor grant provides editing access even if another grant is Viewer.

Admin accounts have system reporting and account-management privileges. The Admin role alone does not grant ownership or editing rights over another person's file.

## 11. Groups and membership

Open **Reports & Groups**, click **+ New group**, enter a unique group name and optional description, then create it. Its creator becomes a member automatically.

Click **Manage members**, select an existing account and use the add control. Repeat for additional members. Members must first have CloudVault accounts. The group creator or an Admin can add/remove members; other users can inspect membership but cannot change it.

To share a file with a group, open that file's **Access** tab, select the group under **Groups**, choose Editor or Viewer and click **Grant**. The file stays in its owner's library. Members gain access through the group and can find accessible shared files in group navigation.

Removing membership or revoking group access removes that route to the file. A separate direct grant or another group grant can still provide access. Groups do not own uploaded files, and uploading while viewing a group does not automatically share the new file with that group.

## 12. Public share links

The owner can open **Share links**, optionally select an expiry date and positive maximum download count, then click **Create new link**. **Copy** copies a URL on the current application's origin. **Revoke** removes that link.

Public links do not require the recipient to sign in. The server checks the token, expiry, download limit, file deletion status and content availability. Successful public downloads increase the counter and create an activity event. Download-limit checks and updates occur in a database transaction to prevent exceeding the limit through simultaneous requests.

Several links can refer to one file, each with its own conditions. A link downloads the current version, so a later upload changes the content downloaded through it. A localhost URL works on the machine running the app; sharing outside that machine requires a reachable deployment.

## 13. Deleted files and recovery

Normal deletion sets `is_deleted` and `deleted_at`, records a Delete event and removes the file from active views. The content and versions remain available for recovery.

Open **Deleted**, select the file and click **Restore** to return it to the library. A Restore event records the action. Files in Deleted cannot be downloaded or modified until restored.

Permanent deletion requires the file to be in Deleted first. The interface asks for confirmation before removing the file and its dependent version, tag-association, permission, link and activity records. This cannot be recovered through the app. Unreferenced content objects are not automatically garbage-collected.

## 14. Bulk operations

Select file checkboxes to reveal the selection toolbar. It supports downloading selected files, moving files, adding a tag, deleting files and clearing the selection. In Deleted, bulk deletion is permanent and requires confirmation.

Each operation remains subject to its normal permission and quota checks. Bulk actions run per file rather than as one all-or-nothing transaction; an error can leave earlier files already processed. Browsers may request permission for multiple downloads.

## 15. Storage usage and quotas

The sidebar shows used storage against the signed-in user's quota. Usage is derived from the total size of all owned version records, including historical versions and Deleted files. Soft deletion therefore does not reduce quota usage; permanent deletion does.

The server checks quota before uploads, new versions, copies and version restoration. Reports separately display duplicate savings based on shared content paths. Logical quota usage and physical object storage are different measurements.

## 16. Reports and administrator controls

**Reports & Groups** combines usage information, duplicate savings, share-link information, Deleted-file counts, groups, membership, recent activity and matching-checksum records. Ordinary users see file details within their access scope; Admins have the system-wide reporting snapshot.

The **Admin** page provides account totals, storage totals, group totals, active-file totals, role selectors and quota controls. Only Admin accounts can use the corresponding user-update API. Valid roles are Student, Faculty and Admin; quotas must be nonnegative integer byte values at the API level.

## 17. Activity tracking

Activity records connect an acting user, a file, an action type, a timestamp and details. Supported types are Upload, Share, Modify, Delete, Restore and Download. Renaming, moving, permission updates and tag changes use appropriate events. The file's Activity tab displays its history, and reports display recent accessible events.

A public download is recorded against the link creator with details identifying public-link use, because the anonymous recipient has no user account.

## 18. Database design

The authoritative design is `resources/CloudVault_DB_Design.docx`. The abstract explains the project scope. `resources/03. DB Design.pdf` is a blank assignment template.

| Table | Purpose |
| --- | --- |
| users | Identity, password hash, role, quota, maintained usage and creation time. |
| user_groups | Group name, description, creator and creation time. |
| group_members | Many-to-many user membership with join timestamps. |
| folders | Named, owned folders with optional parent folders. |
| files | Logical file identity, owner, folder and soft-deletion state. |
| file_versions | Sequential content snapshots, checksums, paths and uploader information. |
| tags | Unique reusable tag names. |
| file_tags | Many-to-many file/tag associations. |
| file_user_permissions | Direct user access level and grant provenance. |
| file_group_permissions | Group access level and grant provenance. |
| share_links | Unique tokens, expiry, maximum downloads and counters. |
| activity_logs | File events with actor, timestamp and details. |

Primary keys identify records. Foreign keys enforce relationships. Composite keys represent membership, tags and sharing associations. Alternate unique constraints cover emails, names in specified scopes, tokens and per-file version numbers.

`server/schema.mysql.sql` follows the document's twelve-table DDL, with AUTO_INCREMENT added for API-generated surrogate IDs. `server/schema.sql` is the SQLite equivalent. The narrative mentions Owner for group sharing, but its DDL allows Editor/Viewer; the implementation follows the DDL and keeps one owning user per file. See `FEATURE_AUDIT.md` for the full feature-to-design mapping.

## 19. Optional MySQL backend

Create an empty MySQL database and apply the schema:

```sh
mysql -u your_user -p -e "CREATE DATABASE cloudvault CHARACTER SET utf8mb4;"
mysql -u your_user -p cloudvault < server/schema.mysql.sql
```

Configure the environment before starting Flask:

```sh
export DATABASE_BACKEND=mysql
export MYSQL_HOST=127.0.0.1
export MYSQL_PORT=3306
export MYSQL_DATABASE=cloudvault
export MYSQL_USER=your_user
export MYSQL_PASSWORD='your database password'
export CLOUDVAULT_SECRET='your persistent random session signing key'
```

These examples use POSIX shell syntax; PowerShell uses `$env:VARIABLE = 'value'`. The MySQL mode does not import the bundled SQLite accounts or reset a database automatically. Register an account, then provision the first administrator using an authorised database connection:

```sql
UPDATE users SET role='Admin' WHERE email='your-admin-email';
```

Further role/quota management is available in the Admin page. MySQL 8.4 schema application and end-to-end API flows were verified against a temporary database.

## 20. Optional S3 object storage

```sh
export STORAGE_BACKEND=s3
export S3_BUCKET=your-private-bucket
export AWS_DEFAULT_REGION=your-region
```

Provide credentials through the normal AWS SDK chain: environment, profile or instance role. Set `S3_ENDPOINT_URL` for a compatible provider when needed. Create the bucket separately and permit the application to inspect, upload and retrieve its objects.

Objects use checksum keys. Metadata stores `s3://bucket/checksum` paths. Downloads are served through the application, and the bucket does not need public access. Existing local versions retain local paths; switching backends does not migrate existing objects. S3 upload/reuse behavior was tested using AWS SDK stub responses, not a live bucket.

## 21. Configuration reference

| Variable | Default or purpose |
| --- | --- |
| DATABASE_BACKEND | `sqlite`; use `mysql` for MySQL. |
| MYSQL_HOST / MYSQL_PORT | `127.0.0.1` / `3306`. |
| MYSQL_DATABASE | `cloudvault`. |
| MYSQL_USER / MYSQL_PASSWORD | Required MySQL credentials. |
| STORAGE_BACKEND | `local`; use `s3` for object storage. |
| S3_BUCKET | Required bucket for S3 uploads. |
| S3_ENDPOINT_URL | Optional compatible-provider endpoint. |
| AWS_DEFAULT_REGION | AWS SDK region configuration. |
| CLOUDVAULT_SECRET | Persistent session signing key; local fallback is an owner-only `.session-secret` file. |
| FLASK_DEBUG | Debug mode enabled only when set to `1`. |

For deployment, use HTTPS, a production WSGI server, private credentials and a stable session signing key. The included Flask launch command is intended for a local demonstration.

## 22. Testing and resetting

Run isolated automated checks:

```sh
server/venv/bin/python -m unittest discover -s server/tests -v
node --check app/js/db.js
node --check app/js/dashboard.js
node --check app/js/reports.js
```

The seven automated tests cover access restrictions, owner protection, private snapshots, folders, copying, group sharing/revocation, tags, version history/restoration, duplicate reuse, quota enforcement, recovery, public links, admin validation, password migration and S3 reuse. They use disposable databases/content and do not reset the bundled database.

An additional `server/tests/mysql_integration.py` script targets an empty disposable MySQL 8.4 database on port 33079 with its explicitly configured test credentials. It is not intended for a live project database.

To reset the local SQLite demonstration explicitly:

```sh
server/venv/bin/python server/seed.py
```

**Reset clears every account, group, folder, file, version, tag, permission, share link, activity entry and local uploaded object, then creates Test and Admin again.** It does not reset a MySQL database or delete S3 objects. Stop the app before intentionally resetting demo data.

## 23. Package structure

```text
CloudVault/
  README.md
  FEATURE_AUDIT.md
  design.md
  app/
    login.html, dashboard.html, reports.html, admin.html
    css/                         Shared tokens and page styling
    js/                          API client and page interactions
  server/
    app.py                       Flask API and business rules
    database.py                  MySQL connection adapter
    storage.py                   Local/S3 content storage
    schema.sql                   SQLite schema
    schema.mysql.sql             MySQL design schema
    seed.py                      Explicit two-account demo reset
    requirements.txt             Python dependencies
    cloudvault.db                Empty two-account SQLite demo
    uploads/                     Local uploaded content directory
    tests/                       Automated rules/storage checks
  resources/                     Original abstract and design documents
```

The archive excludes virtual environments, caches, session secrets, old project archives and local development-tool metadata.

## 24. Troubleshooting and practical limits

- **Connection refused:** start Flask and keep its terminal running; confirm port 5050 is available.
- **Missing Flask/PyMySQL/boto3:** install requirements using the virtual environment's Python.
- **Quota exceeded:** older versions and Deleted files still count. Permanently delete unneeded files or ask an Admin to increase quota.
- **Cannot manage a group:** only its creator or an Admin may change membership.
- **Cannot share or delete a file:** those actions require file ownership; Editor access is insufficient.
- **Share link stops working:** check expiry, download count, revocation, deletion status and content availability.
- **Upload name conflicts with Deleted:** restore the existing file or use another filename.
- **Local link fails on another computer:** localhost URLs address the recipient's own machine. Use a reachable deployment for remote sharing.
- **Unavailable historical content:** version metadata cannot reconstruct a missing object. Keep the database and its referenced local/S3 objects together when backing up or moving the app.

This build has no email invitations, password-reset flow, folder deletion UI, content preview, Git-style merging or automatic object garbage collection. It is a coursework file-management implementation, with configurable deployment backends and the documented relational model.
